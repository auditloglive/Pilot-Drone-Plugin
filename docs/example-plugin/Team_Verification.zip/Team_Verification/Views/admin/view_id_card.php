<?php
if ($verification->photo_file) {
    $photo_url = base_url(PLUGIN_URL_PATH . 'Team_Verification/files/photos/' . $verification->photo_file);
} else {
    $photo_url = base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/default-avatar.svg');
}

$profile_url = base_url('index.php/public_team/profile/' . $verification->uuid);
$qr_code_url = 'https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=' . urlencode($profile_url);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ID Card - <?php echo $user_info->first_name . ' ' . $user_info->last_name; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        
        .controls {
            max-width: 800px;
            margin: 0 auto 20px;
            text-align: center;
        }
        
        .card-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 60vh;
            padding: 40px 20px;
        }
        
        .id-card {
            width: 3.375in;
            height: 2.125in;
            border: 2px solid #333;
            border-radius: 8px;
            overflow: hidden;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 8px 16px rgba(0,0,0,0.3);
        }
        
        .id-card-header {
            background: rgba(255,255,255,0.95);
            color: #333;
            padding: 8px;
            text-align: center;
            font-weight: bold;
            font-size: 12px;
            border-bottom: 2px solid #667eea;
        }
        
        .id-card-body {
            display: flex;
            padding: 12px;
            gap: 12px;
        }
        
        .id-photo {
            width: 90px;
            height: 110px;
            border-radius: 6px;
            border: 3px solid white;
            object-fit: cover;
            background: white;
        }
        
        .id-details {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        
        .id-name {
            font-size: 16px;
            font-weight: bold;
            margin: 0 0 4px 0;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
        }
        
        .id-title {
            font-size: 11px;
            margin: 0 0 8px 0;
            opacity: 0.95;
        }
        
        .id-uid {
            background: white;
            color: #667eea;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 6px;
        }
        
        .id-status {
            background: <?php echo $verification->dbs_status === 'verified' ? '#28a745' : '#ffc107'; ?>;
            color: white;
            padding: 3px 6px;
            border-radius: 3px;
            font-size: 9px;
            text-align: center;
            font-weight: bold;
        }
        
        .id-qr {
            text-align: center;
        }
        
        .id-qr img {
            width: 90px;
            height: 90px;
            background: white;
            padding: 4px;
            border-radius: 4px;
        }
        
        .id-qr-label {
            font-size: 7px;
            margin-top: 2px;
            opacity: 0.9;
        }
        
        @media print {
            body {
                margin: 0;
                padding: 0;
                background: white;
            }
            
            .controls {
                display: none !important;
            }
            
            .card-container {
                min-height: auto;
                padding: 0;
                display: block;
            }
            
            .id-card {
                margin: 0;
                box-shadow: none;
                page-break-after: always;
            }
            
            @page {
                size: 3.375in 2.125in;
                margin: 0;
            }
        }
        
        @media screen and (max-width: 768px) {
            .id-card {
                transform: scale(0.9);
            }
        }
    </style>
</head>
<body>
    <div class="controls">
        <a href="<?php echo get_uri('team_verification/manage/' . $user_info->id); ?>" class="btn btn-secondary me-2">
            <i class="fa fa-arrow-left"></i> Back
        </a>
        <button onclick="window.print()" class="btn btn-primary me-2">
            <i class="fa fa-print"></i> Print ID Card
        </button>
        <button onclick="downloadAsImage()" class="btn btn-success">
            <i class="fa fa-download"></i> Download as Image
        </button>
    </div>
    
    <div class="card-container">
        <div class="id-card" id="idCard">
            <div class="id-card-header">
                AUTHORIZED TEAM MEMBER ID
            </div>
            <div class="id-card-body">
                <div>
                    <img src="<?php echo $photo_url; ?>" class="id-photo" alt="Photo" crossorigin="anonymous">
                </div>
                <div class="id-details">
                    <div>
                        <div class="id-name"><?php echo $user_info->first_name . ' ' . $user_info->last_name; ?></div>
                        <div class="id-title"><?php echo $user_info->job_title ? $user_info->job_title : 'Team Member'; ?></div>
                        <?php if ($verification->uid_card_number) { ?>
                        <div class="id-uid">UID: <?php echo $verification->uid_card_number; ?></div>
                        <?php } ?>
                        <div class="id-status"><?php echo $verification->dbs_status === 'verified' ? 'DBS VERIFIED' : 'VERIFICATION PENDING'; ?></div>
                    </div>
                </div>
                <div class="id-qr">
                    <img src="<?php echo $qr_code_url; ?>" alt="QR" crossorigin="anonymous">
                    <div class="id-qr-label">SCAN TO VERIFY</div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
    <script>
        async function downloadAsImage() {
            const card = document.getElementById('idCard');
            const canvas = await html2canvas(card, {
                scale: 3,
                backgroundColor: null,
                useCORS: true,
                allowTaint: false
            });
            
            const link = document.createElement('a');
            link.download = 'id-card-<?php echo $verification->uid_card_number ? $verification->uid_card_number : $user_info->id; ?>.png';
            link.href = canvas.toDataURL('image/png');
            link.click();
        }
    </script>
</body>
</html>
