<!-- Quick Navigation Bar -->
<div class="card mb-3" style="border-left: 4px solid #667eea;">
    <div class="card-body py-2">
        <div class="d-flex flex-wrap gap-2">
            <a href="<?php echo get_uri('team_verification/list_view'); ?>" class="btn btn-sm btn-primary">
                <i class="fa fa-users"></i> Team List
            </a>
            <a href="<?php echo get_uri('team_verification/public_directory'); ?>" class="btn btn-sm btn-info" target="_blank">
                <i class="fa fa-globe"></i> Public Directory
            </a>
            <a href="<?php echo get_uri('team_verification/list_view?show_backup=1'); ?>" class="btn btn-sm btn-success">
                <i class="fa fa-database"></i> Backup & Restore
            </a>
            <a href="<?php echo get_uri('team_verification/settings'); ?>" class="btn btn-sm btn-warning">
                <i class="fa fa-cog"></i> Settings & Debug
            </a>
            <a href="<?php echo get_uri('team_verification/live_debug'); ?>" class="btn btn-sm btn-secondary">
                <i class="fa fa-bug"></i> Live Logs
            </a>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h4><?php echo app_lang('tv_manage_verification'); ?>: <?php echo $user_info->first_name . ' ' . $user_info->last_name; ?></h4>
        <a href="<?php echo get_uri('team_verification'); ?>" class="btn btn-sm btn-secondary float-end">
            <i class="fa fa-arrow-left"></i> <?php echo app_lang('back'); ?>
        </a>
    </div>
    <div class="card-body">
        <?php 
        // DEBUG INFO - Shows folder status directly on page
        $base_path = PLUGINPATH . 'Team_Verification/assets/verification/users/';
        $pending_path = $base_path . 'pending/';
        $temp_path = get_setting("temp_file_path");
        ?>
        <div class="alert alert-info mb-3" style="font-size: 13px;">
            <strong>📁 Storage Debug:</strong>
            Base: <?php echo is_dir($base_path) && is_writable($base_path) ? '<span style="color:green;font-weight:bold;">✅ OK</span>' : '<span style="color:red;font-weight:bold;">❌ FAIL</span>'; ?> | 
            Pending: <?php echo is_dir($pending_path) && is_writable($pending_path) ? '<span style="color:green;font-weight:bold;">✅ OK</span>' : '<span style="color:red;font-weight:bold;">❌ FAIL</span>'; ?> | 
            Temp: <?php echo is_dir($temp_path) && is_writable($temp_path) ? '<span style="color:green;font-weight:bold;">✅ OK</span>' : '<span style="color:red;font-weight:bold;">❌ FAIL</span>'; ?> <small>(<?php echo $temp_path; ?>)</small>
        </div>

        <?php echo form_open(get_uri("team_verification/save"), array("id" => "verification-form", "class" => "general-form", "role" => "form")); ?>
        
        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>" />
        
        <div class="row">
            <div class="col-md-6">
                <h5 class="mb-3"><?php echo app_lang('tv_card_information'); ?></h5>
                
                <div class="form-group mb-3">
                    <label for="uid_card_number"><?php echo app_lang('tv_uid_card_number'); ?></label>
                    <div class="input-group">
                        <input type="text" name="uid_card_number" id="uid_card_number" class="form-control" value="<?php echo $verification->uid_card_number; ?>" />
                        <?php if (empty($verification->uid_card_number)) { ?>
                        <button type="button" class="btn btn-info" id="generate-uid-btn">
                            <i class="fa fa-magic"></i> <?php echo app_lang('tv_generate_uid'); ?>
                        </button>
                        <?php } ?>
                    </div>
                    <small class="form-text text-muted"><?php echo app_lang('tv_uid_card_number_help'); ?></small>
                </div>

                <h5 class="mb-3 mt-4"><?php echo app_lang('tv_dbs_information'); ?></h5>
                
                <div class="form-group mb-3">
                    <label for="dbs_status"><?php echo app_lang('tv_dbs_status'); ?> <span class="text-danger">*</span></label>
                    <select name="dbs_status" id="dbs_status" class="form-control" required>
                        <option value="pending" <?php echo ($verification->dbs_status == 'pending') ? 'selected' : ''; ?>><?php echo app_lang('tv_status_pending'); ?></option>
                        <option value="verified" <?php echo ($verification->dbs_status == 'verified') ? 'selected' : ''; ?>><?php echo app_lang('tv_status_verified'); ?></option>
                        <option value="expired" <?php echo ($verification->dbs_status == 'expired') ? 'selected' : ''; ?>><?php echo app_lang('tv_status_expired'); ?></option>
                        <option value="rejected" <?php echo ($verification->dbs_status == 'rejected') ? 'selected' : ''; ?>><?php echo app_lang('tv_status_rejected'); ?></option>
                    </select>
                </div>

                <div class="form-group mb-3">
                    <label for="dbs_certificate_number"><?php echo app_lang('tv_dbs_certificate_number'); ?></label>
                    <input type="text" name="dbs_certificate_number" id="dbs_certificate_number" class="form-control" value="<?php echo $verification->dbs_certificate_number; ?>" />
                </div>

                <div class="form-group mb-3">
                    <label for="dbs_issue_date"><?php echo app_lang('tv_dbs_issue_date'); ?></label>
                    <input type="date" name="dbs_issue_date" id="dbs_issue_date" class="form-control" value="<?php echo $verification->dbs_issue_date; ?>" />
                </div>

                <div class="form-group mb-3">
                    <label for="dbs_expiry_date"><?php echo app_lang('tv_dbs_expiry_date'); ?></label>
                    <input type="date" name="dbs_expiry_date" id="dbs_expiry_date" class="form-control" value="<?php echo $verification->dbs_expiry_date; ?>" />
                </div>
            </div>

            <div class="col-md-6">
                <h5 class="mb-3"><?php echo app_lang('tv_identification_information'); ?></h5>
                
                <div class="form-group mb-3">
                    <label for="identification_type"><?php echo app_lang('tv_identification_type'); ?></label>
                    <select name="identification_type" id="identification_type" class="form-control">
                        <option value=""><?php echo app_lang('select'); ?></option>
                        <option value="passport" <?php echo ($verification->identification_type == 'passport') ? 'selected' : ''; ?>><?php echo app_lang('tv_passport'); ?></option>
                        <option value="drivers_license" <?php echo ($verification->identification_type == 'drivers_license') ? 'selected' : ''; ?>><?php echo app_lang('tv_drivers_license'); ?></option>
                        <option value="national_id" <?php echo ($verification->identification_type == 'national_id') ? 'selected' : ''; ?>><?php echo app_lang('tv_national_id'); ?></option>
                        <option value="other" <?php echo ($verification->identification_type == 'other') ? 'selected' : ''; ?>><?php echo app_lang('tv_other'); ?></option>
                    </select>
                </div>

                <div class="form-group mb-3">
                    <label for="identification_number"><?php echo app_lang('tv_identification_number'); ?></label>
                    <input type="text" name="identification_number" id="identification_number" class="form-control" value="<?php echo $verification->identification_number; ?>" />
                </div>

                <div class="form-group mb-3">
                    <div class="form-check">
                        <input type="checkbox" name="public_visibility" id="public_visibility" class="form-check-input" value="1" <?php echo ($verification->public_visibility) ? 'checked' : ''; ?> />
                        <label class="form-check-label" for="public_visibility">
                            <?php echo app_lang('tv_show_on_public_directory'); ?>
                        </label>
                    </div>
                    <small class="form-text text-muted"><?php echo app_lang('tv_public_visibility_help'); ?></small>
                </div>

                <div class="form-group mb-3">
                    <label for="verification_notes"><?php echo app_lang('tv_verification_notes'); ?></label>
                    <textarea name="verification_notes" id="verification_notes" class="form-control" rows="4"><?php echo $verification->verification_notes; ?></textarea>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <h5 class="mb-3"><?php echo app_lang('tv_photo_upload'); ?></h5>
                
                <?php 
                // Only show current photo if verification photo exists (not Rise CRM profile)
                if (!empty($verification->photo_file)) {
                    // Use helper function to get correct photo URL (UID-based path)
                    $photo_url = get_verification_photo_url($verification, $user_id);
                    if ($photo_url) {
                ?>
                <div class="mb-3">
                    <label><?php echo app_lang('tv_current_photo'); ?></label>
                    <div class="mb-2">
                        <img src="<?php echo $photo_url; ?>" 
                             alt="Team member photo" 
                             style="max-width: 200px; max-height: 200px;" 
                             class="img-thumbnail"
                             onerror="this.src='<?php echo base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/default-avatar.svg'); ?>';">
                    </div>
                    <button type="button" class="btn btn-danger btn-sm" onclick="deleteFile(<?php echo $user_id; ?>, 'photo')">
                        <i class="fa fa-trash"></i> <?php echo app_lang('delete'); ?>
                    </button>
                </div>
                <?php 
                    }
                } 
                ?>

                <div class="form-group">
                    <label for="photo_file_input"><?php echo app_lang('tv_photo_upload'); ?></label>
                    <input type="file" 
                           id="photo_file_input" 
                           name="photo_file_input" 
                           class="form-control" 
                           accept="image/*,application/pdf" />
                    <input type="hidden" name="photo_file" id="photo_file" value="" />
                    <small class="form-text text-muted"><?php echo app_lang('tv_photo_upload_help'); ?></small>
                </div>
            </div>

            <div class="col-md-6">
                <h5 class="mb-3"><?php echo app_lang('tv_id_document_upload'); ?></h5>
                
                <?php 
                // Only show current document if verification document exists
                if (!empty($verification->id_document_file)) {
                    // Use helper function to get correct document URL (UID-based path)
                    $document_url = get_verification_document_url($verification, $user_id);
                    if ($document_url) {
                ?>
                <div class="mb-3">
                    <label><?php echo app_lang('tv_current_document'); ?></label>
                    <div class="mb-2">
                        <a href="<?php echo $document_url; ?>" 
                           target="_blank" 
                           class="btn btn-sm btn-info">
                            <i class="fa fa-file"></i> <?php echo app_lang('view_document'); ?>
                        </a>
                    </div>
                    <button type="button" class="btn btn-danger btn-sm" onclick="deleteFile(<?php echo $user_id; ?>, 'document')">
                        <i class="fa fa-trash"></i> <?php echo app_lang('delete'); ?>
                    </button>
                </div>
                <?php 
                    }
                } 
                ?>

                <div class="form-group">
                    <label for="id_document_file_input"><?php echo app_lang('tv_id_document_upload'); ?></label>
                    <input type="file" 
                           id="id_document_file_input" 
                           name="id_document_file_input" 
                           class="form-control" 
                           accept="image/*,application/pdf" />
                    <input type="hidden" name="id_document_file" id="id_document_file" value="" />
                    <small class="form-text text-muted"><?php echo app_lang('tv_id_document_upload_help'); ?></small>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <h5 class="mb-3"><i class="fas fa-qrcode me-2"></i><?php echo app_lang('tv_qr_code'); ?></h5>
                <div class="card">
                    <div class="card-body text-center">
                        <?php 
                        $profile_uuid = $verification->uuid ? $verification->uuid : 'pending';
                        $profile_url = base_url('index.php/public_team/profile/' . $profile_uuid);
                        $qr_code_url = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' . urlencode($profile_url);
                        ?>
                        <?php if ($verification->uuid) { ?>
                        <img src="<?php echo $qr_code_url; ?>" alt="QR Code" class="img-fluid mb-3" style="max-width: 250px;">
                        <p class="small text-muted mb-3">Public profile QR code</p>
                        <div class="d-grid gap-2">
                            <a href="<?php echo $qr_code_url; ?>&download=1" download="qr-code-<?php echo $profile_uuid; ?>.png" class="btn btn-sm btn-primary">
                                <i class="fa fa-download"></i> <?php echo app_lang('tv_download_qr'); ?>
                            </a>
                            <a href="<?php echo get_uri('team_verification/view_id_card/' . $user_id); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                <i class="fa fa-id-card"></i> View ID Card
                            </a>
                            <button type="button" class="btn btn-sm btn-success" onclick="printBadgy100()">
                                <i class="fa fa-id-badge"></i> Print Badgy 100
                            </button>
                            <button type="button" class="btn btn-sm btn-warning" onclick="downloadBadgeStudio()">
                                <i class="fa fa-download"></i> BadgeStudio Export
                            </button>
                            <a href="<?php echo $profile_url; ?>" target="_blank" class="btn btn-sm btn-info">
                                <i class="fa fa-external-link"></i> <?php echo app_lang('tv_view_public_profile'); ?>
                            </a>
                        </div>
                        <?php } else { ?>
                        <p class="text-muted"><i class="fa fa-info-circle"></i> QR code will be generated after saving</p>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <h5 class="mb-3">&nbsp;</h5>
                <div class="alert alert-info">
                    <h6><i class="fas fa-info-circle me-2"></i><?php echo app_lang('tv_qr_code_info_title'); ?></h6>
                    <p class="small mb-2"><?php echo app_lang('tv_qr_code_info_text'); ?></p>
                    <ul class="small mb-0">
                        <li><?php echo app_lang('tv_qr_code_use_1'); ?></li>
                        <li><?php echo app_lang('tv_qr_code_use_2'); ?></li>
                        <li><?php echo app_lang('tv_qr_code_use_3'); ?></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> <?php echo app_lang('save'); ?>
                </button>
            </div>
        </div>

        <?php echo form_close(); ?>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        console.log("Team Verification form initializing...");
        
        $("#verification-form").appForm({
            isModal: false,
            onSuccess: function (result) {
                appAlert.success(result.message, {duration: 10000});
                location.reload();
            }
        });

        // Simple file upload using FormData and AJAX
        $("#photo_file_input").on("change", function() {
            var file = this.files[0];
            if (!file) return;
            
            console.log("Photo file selected:", file.name);
            appAlert.info("Uploading photo...", {duration: 3000});
            
            var formData = new FormData();
            formData.append("file", file);
            
            $.ajax({
                url: "<?php echo get_uri("team_verification/upload_file"); ?>",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(result) {
                    console.log("Photo upload response:", result);
                    if (result && result.success) {
                        $("#photo_file").val(result.file_name);
                        appAlert.success("Photo uploaded successfully!");
                    } else {
                        appAlert.error(result.message || "Photo upload failed");
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Photo upload error:", xhr.responseText);
                    appAlert.error("Photo upload failed: " + error);
                }
            });
        });

        $("#id_document_file_input").on("change", function() {
            var file = this.files[0];
            if (!file) return;
            
            console.log("Document file selected:", file.name);
            appAlert.info("Uploading document...", {duration: 3000});
            
            var formData = new FormData();
            formData.append("file", file);
            
            $.ajax({
                url: "<?php echo get_uri("team_verification/upload_file"); ?>",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(result) {
                    console.log("Document upload response:", result);
                    if (result && result.success) {
                        $("#id_document_file").val(result.file_name);
                        appAlert.success("Document uploaded successfully!");
                    } else {
                        appAlert.error(result.message || "Document upload failed");
                    }
                },
                error: function(xhr, status, error) {
                    console.error("Document upload error:", xhr.responseText);
                    appAlert.error("Document upload failed: " + error);
                }
            });
        });
        
        console.log("Simple file upload handlers initialized");
    });

    $("#generate-uid-btn").on("click", function() {
        $.ajax({
            url: "<?php echo get_uri("team_verification/generate_uid"); ?>",
            type: 'POST',
            dataType: 'json',
            success: function(result) {
                if (result.success && result.uid) {
                    $("#uid_card_number").val(result.uid);
                    appAlert.success(result.message || "UID generated successfully");
                } else {
                    appAlert.error(result.message || "Error generating UID");
                }
            },
            error: function() {
                appAlert.error("Error generating UID");
            }
        });
    });

    function deleteFile(userId, fileType) {
        if (confirm("<?php echo app_lang('confirm_delete'); ?>")) {
            $.ajax({
                url: "<?php echo get_uri("team_verification/delete_file"); ?>",
                type: 'POST',
                data: {user_id: userId, file_type: fileType},
                dataType: 'json',
                success: function(result) {
                    if (result.success) {
                        appAlert.success(result.message || "File deleted successfully");
                        location.reload();
                    } else {
                        appAlert.error(result.message || "Error deleting file");
                    }
                }
            });
        }
    }

    function printBadgy100() {
        const qrCodeUrl = <?php echo json_encode($qr_code_url); ?> + '&size=150x150';
        const userName = <?php echo json_encode($user_info->first_name . ' ' . $user_info->last_name); ?>;
        const jobTitle = <?php echo json_encode($user_info->job_title ? $user_info->job_title : ''); ?>;
        const uidNumber = <?php echo json_encode($verification->uid_card_number ? $verification->uid_card_number : ''); ?>;
        const dbsStatus = <?php echo json_encode($verification->dbs_status); ?>;
        const photoUrl = <?php 
            $js_photo_url = '';
            if (!empty($verification->photo_file)) {
                $js_photo_url = get_verification_photo_url($verification, $user_id);
            }
            if (!$js_photo_url) {
                $js_photo_url = base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/default-avatar.svg');
            }
            echo json_encode($js_photo_url); 
        ?>;
        
        const printWindow = window.open('', '', 'width=900,height=600');
        printWindow.document.write(`
            <html>
            <head>
                <title>Badgy 100 ID Card - ${userName}</title>
                <style>
                    @media print {
                        body { margin: 0; padding: 0; }
                        @page { size: 85.6mm 54mm; margin: 0; }
                    }
                    body { 
                        font-family: Arial, sans-serif; 
                        padding: 10mm;
                        margin: 0;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        min-height: 100vh;
                        background: #f0f0f0;
                    }
                    .badge-card {
                        width: 85.6mm;
                        height: 54mm;
                        border: 1px solid #ccc;
                        border-radius: 3mm;
                        overflow: hidden;
                        background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
                        color: white;
                        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
                        display: flex;
                        position: relative;
                    }
                    .badge-left {
                        width: 30mm;
                        background: rgba(255,255,255,0.1);
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        padding: 5mm 2mm;
                        border-right: 1px solid rgba(255,255,255,0.3);
                    }
                    .badge-photo {
                        width: 25mm;
                        height: 30mm;
                        border-radius: 2mm;
                        border: 2px solid white;
                        object-fit: cover;
                        background: white;
                        margin-bottom: 3mm;
                    }
                    .badge-qr {
                        width: 18mm;
                        height: 18mm;
                        background: white;
                        padding: 1mm;
                        border-radius: 1mm;
                    }
                    .badge-qr img {
                        width: 100%;
                        height: 100%;
                    }
                    .badge-right {
                        flex: 1;
                        padding: 5mm 4mm;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                    }
                    .badge-header {
                        position: absolute;
                        top: 0;
                        left: 0;
                        right: 0;
                        background: rgba(255,255,255,0.95);
                        color: #333;
                        padding: 2mm;
                        text-align: center;
                        font-weight: bold;
                        font-size: 8pt;
                    }
                    .badge-name {
                        font-size: 14pt;
                        font-weight: bold;
                        margin: 8mm 0 2mm 0;
                        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
                        line-height: 1.2;
                    }
                    .badge-title {
                        font-size: 9pt;
                        margin-bottom: 3mm;
                        opacity: 0.95;
                    }
                    .badge-uid {
                        background: white;
                        color: #4a90e2;
                        padding: 1.5mm 3mm;
                        border-radius: 2mm;
                        font-size: 8pt;
                        font-weight: bold;
                        display: inline-block;
                        margin-bottom: 2mm;
                    }
                    .badge-status {
                        background: ${dbsStatus === 'verified' ? '#28a745' : '#ffc107'};
                        color: white;
                        padding: 1mm 2mm;
                        border-radius: 2mm;
                        font-size: 7pt;
                        font-weight: bold;
                        display: inline-block;
                    }
                </style>
            </head>
            <body>
                <div class="badge-card">
                    <div class="badge-header">AUTHORIZED TEAM MEMBER</div>
                    <div class="badge-left">
                        <img src="${photoUrl}" class="badge-photo" alt="Photo">
                        <div class="badge-qr">
                            <img src="${qrCodeUrl}" alt="QR">
                        </div>
                    </div>
                    <div class="badge-right">
                        <div class="badge-name">${userName}</div>
                        <div class="badge-title">${jobTitle || 'Team Member'}</div>
                        ${uidNumber ? '<div class="badge-uid">' + uidNumber + '</div>' : ''}
                        <div class="badge-status">${dbsStatus === 'verified' ? 'DBS VERIFIED' : 'PENDING'}</div>
                    </div>
                </div>
            </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.onload = function() {
            setTimeout(function() {
                printWindow.print();
            }, 500);
        };
    }

    function downloadBadgeStudio() {
        const userName = <?php echo json_encode($user_info->first_name . ' ' . $user_info->last_name); ?>;
        const firstName = <?php echo json_encode($user_info->first_name); ?>;
        const lastName = <?php echo json_encode($user_info->last_name); ?>;
        const jobTitle = <?php echo json_encode($user_info->job_title ? $user_info->job_title : ''); ?>;
        const email = <?php echo json_encode($user_info->email); ?>;
        const uidNumber = <?php echo json_encode($verification->uid_card_number ? $verification->uid_card_number : ''); ?>;
        const dbsStatus = <?php echo json_encode($verification->dbs_status); ?>;
        const photoFile = <?php echo json_encode($verification->photo_file ? $verification->photo_file : ''); ?>;
        const profileUrl = <?php echo json_encode($profile_url); ?>;
        
        // Create CSV content for BadgeStudio import
        let csv = 'FirstName,LastName,JobTitle,Email,UID,DBSStatus,PhotoURL,ProfileURL\n';
        csv += `"${firstName}","${lastName}","${jobTitle}","${email}","${uidNumber}","${dbsStatus}","${photoFile}","${profileUrl}"`;
        
        // Create downloadable file
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', 'badgestudio_import_' + uidNumber.replace(/[^a-zA-Z0-9]/g, '_') + '.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        appAlert.success('BadgeStudio CSV file downloaded! Import this file into BadgeStudio software.');
    }

    function printQRCodeAdmin() {
        const qrCodeUrl = <?php echo json_encode($qr_code_url); ?> + '&size=180x180';
        const userName = <?php echo json_encode($user_info->first_name . ' ' . $user_info->last_name); ?>;
        const jobTitle = <?php echo json_encode($user_info->job_title ? $user_info->job_title : ''); ?>;
        const uidNumber = <?php echo json_encode($verification->uid_card_number ? $verification->uid_card_number : ''); ?>;
        const dbsStatus = <?php echo json_encode($verification->dbs_status); ?>;
        const photoUrl = <?php 
            $js_photo_url = '';
            if (!empty($verification->photo_file)) {
                $js_photo_url = get_verification_photo_url($verification, $user_id);
            }
            if (!$js_photo_url) {
                $js_photo_url = base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/default-avatar.svg');
            }
            echo json_encode($js_photo_url); 
        ?>;
        
        const printWindow = window.open('', '', 'width=900,height=600');
        printWindow.document.write(`
            <html>
            <head>
                <title>ID Card - ${userName}</title>
                <style>
                    @media print {
                        body { margin: 0; padding: 0; }
                        @page { size: 3.375in 2.125in; margin: 0; }
                    }
                    body { 
                        font-family: Arial, sans-serif; 
                        padding: 0.5in;
                        margin: 0;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        min-height: 100vh;
                    }
                    .id-card {
                        width: 3.375in;
                        height: 2.125in;
                        border: 2px solid #333;
                        border-radius: 8px;
                        overflow: hidden;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.3);
                        page-break-after: always;
                    }
                    .id-card-header {
                        background: rgba(255,255,255,0.95);
                        color: #333;
                        padding: 8px;
                        text-align: center;
                        font-weight: bold;
                        font-size: 12px;
                        border-bottom: 2px solid #667eea;
                    }
                    .id-card-body {
                        display: flex;
                        padding: 12px;
                        gap: 12px;
                    }
                    .id-photo {
                        width: 90px;
                        height: 110px;
                        border-radius: 6px;
                        border: 3px solid white;
                        object-fit: cover;
                        background: white;
                    }
                    .id-details {
                        flex: 1;
                        display: flex;
                        flex-direction: column;
                        justify-content: space-between;
                    }
                    .id-name {
                        font-size: 16px;
                        font-weight: bold;
                        margin: 0 0 4px 0;
                        text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
                    }
                    .id-title {
                        font-size: 11px;
                        margin: 0 0 8px 0;
                        opacity: 0.95;
                    }
                    .id-uid {
                        background: white;
                        color: #667eea;
                        padding: 4px 8px;
                        border-radius: 4px;
                        font-size: 10px;
                        font-weight: bold;
                        text-align: center;
                        margin-bottom: 6px;
                    }
                    .id-status {
                        background: ${dbsStatus === 'verified' ? '#28a745' : '#ffc107'};
                        color: white;
                        padding: 3px 6px;
                        border-radius: 3px;
                        font-size: 9px;
                        text-align: center;
                        font-weight: bold;
                    }
                    .id-qr {
                        text-align: center;
                    }
                    .id-qr img {
                        width: 90px;
                        height: 90px;
                        background: white;
                        padding: 4px;
                        border-radius: 4px;
                    }
                    .id-qr-label {
                        font-size: 7px;
                        margin-top: 2px;
                        opacity: 0.9;
                    }
                </style>
            </head>
            <body>
                <div class="id-card">
                    <div class="id-card-header">
                        AUTHORIZED TEAM MEMBER ID
                    </div>
                    <div class="id-card-body">
                        <div>
                            <img src="${photoUrl}" class="id-photo" alt="Photo">
                        </div>
                        <div class="id-details">
                            <div>
                                <div class="id-name">${userName}</div>
                                <div class="id-title">${jobTitle || 'Team Member'}</div>
                                ${uidNumber ? '<div class="id-uid">UID: ' + uidNumber + '</div>' : ''}
                                <div class="id-status">${dbsStatus === 'verified' ? 'DBS VERIFIED' : 'VERIFICATION PENDING'}</div>
                            </div>
                        </div>
                        <div class="id-qr">
                            <img src="${qrCodeUrl}" alt="QR">
                            <div class="id-qr-label">SCAN TO VERIFY</div>
                        </div>
                    </div>
                </div>
            </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.onload = function() {
            setTimeout(function() {
                printWindow.print();
            }, 500);
        };
    }
</script>
