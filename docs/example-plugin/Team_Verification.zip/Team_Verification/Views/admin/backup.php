<!-- Quick Navigation Bar -->
<div class="card mb-3" style="border-left: 4px solid #667eea;">
    <div class="card-body py-2">
        <div class="d-flex flex-wrap gap-2">
            <a href="<?php echo get_uri('team_verification/list_view'); ?>" class="btn btn-sm btn-primary">
                <i class="fa fa-users"></i> Team List
            </a>
            <a href="<?php echo get_uri('team_verification/public_directory'); ?>" class="btn btn-sm btn-info" target="_blank">
                <i class="fa fa-globe"></i> Public Directory
            </a>
            <a href="<?php echo get_uri('team_verification/list_view?show_backup=1'); ?>" class="btn btn-sm btn-success">
                <i class="fa fa-database"></i> Backup & Restore
            </a>
            <a href="<?php echo get_uri('team_verification/settings'); ?>" class="btn btn-sm btn-warning">
                <i class="fa fa-cog"></i> Settings & Debug
            </a>
            <a href="<?php echo get_uri('team_verification/live_debug'); ?>" class="btn btn-sm btn-secondary">
                <i class="fa fa-bug"></i> Live Logs
            </a>
        </div>
    </div>
</div>

<div class="card rounded-bottom">
    <div class="page-title clearfix">
        <h1>
            <i data-feather="database" class="icon"></i> 
            <?php echo app_lang('tv_backup_restore'); ?>
        </h1>
        <a href="<?php echo get_uri('team_verification'); ?>" class="btn btn-secondary float-end">
            <i data-feather="arrow-left" class="icon"></i> <?php echo app_lang('back'); ?>
        </a>
    </div>

    <div class="card-body">
        <!-- Backup Section -->
        <div class="card mb-4" style="border: 2px solid #28a745;">
            <div class="card-header bg-success text-white">
                <h4 class="mb-0"><i data-feather="download" class="icon"></i> Export Backup</h4>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    <h6><i data-feather="info" class="icon"></i> What gets backed up?</h6>
                    <ul class="mb-0">
                        <li><strong>Database Records:</strong> All verification data (DBS status, UID numbers, dates, etc.)</li>
                        <li><strong>Photos:</strong> All team member verification photos</li>
                        <li><strong>Documents:</strong> All DBS certificates and ID documents</li>
                        <li><strong>Folder Structure:</strong> Complete UID-based organization</li>
                    </ul>
                </div>

                <?php
                $base_path = PLUGINPATH . 'Team_Verification/assets/verification/users/';
                $total_size = 0;
                $file_count = 0;
                
                if (is_dir($base_path)) {
                    $iterator = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($base_path, RecursiveDirectoryIterator::SKIP_DOTS),
                        RecursiveIteratorIterator::SELF_FIRST
                    );
                    foreach ($iterator as $file) {
                        if ($file->isFile()) {
                            $total_size += $file->getSize();
                            $file_count++;
                        }
                    }
                }
                $size_mb = round($total_size / 1024 / 1024, 2);
                ?>

                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <h2 class="text-primary"><?php echo $file_count; ?></h2>
                                <p class="mb-0">Total Files</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <h2 class="text-success"><?php echo $size_mb; ?> MB</h2>
                                <p class="mb-0">Total Size</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-center">
                    <a href="<?php echo get_uri('team_verification/export_backup'); ?>" class="btn btn-success btn-lg">
                        <i data-feather="download" class="icon"></i> Download Backup ZIP
                    </a>
                    <p class="text-muted mt-2 small">Creates: team_verification_backup_<?php echo date('Y-m-d'); ?>.zip</p>
                </div>
            </div>
        </div>

        <!-- Restore Section -->
        <div class="card mb-4" style="border: 2px solid #dc3545;">
            <div class="card-header bg-danger text-white">
                <h4 class="mb-0"><i data-feather="upload" class="icon"></i> Import Backup</h4>
            </div>
            <div class="card-body">
                <div class="alert alert-warning">
                    <h6><i data-feather="alert-triangle" class="icon"></i> Important Warning</h6>
                    <p class="mb-2">Importing a backup will:</p>
                    <ul class="mb-0">
                        <li><strong class="text-danger">Replace all existing files</strong> in verification/users folder</li>
                        <li><strong class="text-danger">Merge database records</strong> (existing records updated, new ones added)</li>
                        <li>This action <strong>cannot be undone</strong> - create a backup first!</li>
                    </ul>
                </div>

                <?php echo form_open_multipart(get_uri("team_verification/import_backup"), array("id" => "import-backup-form")); ?>
                
                <div class="form-group mb-3">
                    <label for="backup_file"><strong>Select Backup ZIP File:</strong></label>
                    <input type="file" name="backup_file" id="backup_file" class="form-control" accept=".zip" required>
                    <small class="form-text text-muted">Only ZIP files created by the Export Backup feature</small>
                </div>

                <div class="form-check mb-3">
                    <input type="checkbox" class="form-check-input" id="confirm_import" name="confirm_import" required>
                    <label class="form-check-label" for="confirm_import">
                        <strong class="text-danger">I understand this will replace existing data and cannot be undone</strong>
                    </label>
                </div>

                <button type="submit" class="btn btn-danger">
                    <i data-feather="upload" class="icon"></i> Import Backup
                </button>
                
                <?php echo form_close(); ?>
            </div>
        </div>

        <!-- Backup History -->
        <div class="card">
            <div class="card-header bg-info text-white">
                <h4 class="mb-0"><i data-feather="clock" class="icon"></i> Backup Best Practices</h4>
            </div>
            <div class="card-body">
                <h6>When to Create Backups:</h6>
                <ul>
                    <li><strong>Before Plugin Updates:</strong> Always backup before updating the plugin</li>
                    <li><strong>Weekly Schedule:</strong> Create weekly backups for safety</li>
                    <li><strong>Before Bulk Changes:</strong> Backup before editing multiple team members</li>
                    <li><strong>Before Server Migrations:</strong> Backup before moving to new hosting</li>
                </ul>

                <h6 class="mt-4">Storage Recommendations:</h6>
                <ul>
                    <li>Store backups in a <strong>safe location</strong> (cloud storage, external drive)</li>
                    <li>Keep <strong>multiple versions</strong> (don't overwrite old backups)</li>
                    <li>Test restore process occasionally to ensure backups work</li>
                    <li>Backup files are portable - works across different servers</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $("#import-backup-form").submit(function(e) {
        if (!$("#confirm_import").is(":checked")) {
            e.preventDefault();
            appAlert.error("Please confirm that you understand the risks");
            return false;
        }
        
        if (!$("#backup_file").val()) {
            e.preventDefault();
            appAlert.error("Please select a backup ZIP file");
            return false;
        }

        appLoader.show();
    });
});

// Initialize Feather icons
if (typeof feather !== 'undefined') {
    feather.replace();
}
</script>
