<!-- Quick Navigation Bar -->
<div class="card mb-3" style="border-left: 4px solid #667eea;">
    <div class="card-body py-2">
        <div class="d-flex flex-wrap gap-2">
            <a href="<?php echo get_uri('team_verification/list_view'); ?>" class="btn btn-sm btn-primary">
                <i class="fa fa-users"></i> Team List
            </a>
            <a href="<?php echo get_uri('team_verification/public_directory'); ?>" class="btn btn-sm btn-info" target="_blank">
                <i class="fa fa-globe"></i> Public Directory
            </a>
            <a href="<?php echo get_uri('team_verification/list_view?show_backup=1'); ?>" class="btn btn-sm btn-success">
                <i class="fa fa-database"></i> Backup & Restore
            </a>
            <a href="<?php echo get_uri('team_verification/settings'); ?>" class="btn btn-sm btn-warning">
                <i class="fa fa-cog"></i> Settings & Debug
            </a>
            <a href="<?php echo get_uri('team_verification/live_debug'); ?>" class="btn btn-sm btn-secondary">
                <i class="fa fa-bug"></i> Live Logs
            </a>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h4><i data-feather="settings" class="icon"></i> Plugin Settings & Diagnostics</h4>
    </div>
    <div class="card-body">
        
        <!-- System Status -->
        <div class="card mb-4" style="border-left: 4px solid #28a745;">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i data-feather="activity" class="icon"></i> System Status</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-sm">
                            <tr>
                                <td><strong>Plugin Version:</strong></td>
                                <td><span class="badge bg-primary">2.2.0</span></td>
                            </tr>
                            <tr>
                                <td><strong>Build Date:</strong></td>
                                <td>2025-11-10</td>
                            </tr>
                            <tr>
                                <td><strong>Database Table:</strong></td>
                                <td>
                                    <?php
                                    $db = db_connect('default');
                                    $db_prefix = get_db_prefix();
                                    if ($db->tableExists($db_prefix . 'team_verification')) {
                                        echo '<span class="badge bg-success">✓ Active</span>';
                                    } else {
                                        echo '<span class="badge bg-danger">✗ Missing</span>';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Total Records:</strong></td>
                                <td>
                                    <?php
                                    if ($db->tableExists($db_prefix . 'team_verification')) {
                                        $count = $db->query("SELECT COUNT(*) as cnt FROM " . $db_prefix . "team_verification")->getRow()->cnt;
                                        echo $count;
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-sm">
                            <tr>
                                <td><strong>Temp Folder:</strong></td>
                                <td>
                                    <?php 
                                    $temp_path = get_setting("temp_file_path");
                                    echo (is_dir($temp_path) && is_writable($temp_path)) 
                                        ? '<span class="badge bg-success">✓ OK</span>' 
                                        : '<span class="badge bg-danger">✗ FAIL</span>';
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Storage Folder:</strong></td>
                                <td>
                                    <?php 
                                    $base_path = PLUGINPATH . 'Team_Verification/assets/verification/users/';
                                    echo (is_dir($base_path) && is_writable($base_path)) 
                                        ? '<span class="badge bg-success">✓ OK</span>' 
                                        : '<span class="badge bg-danger">✗ FAIL</span>';
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Pending Folder:</strong></td>
                                <td>
                                    <?php 
                                    $pending_path = PLUGINPATH . 'Team_Verification/assets/verification/users/pending/';
                                    echo (is_dir($pending_path) && is_writable($pending_path)) 
                                        ? '<span class="badge bg-success">✓ OK</span>' 
                                        : '<span class="badge bg-danger">✗ FAIL</span>';
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>Upload Function:</strong></td>
                                <td>
                                    <?php 
                                    echo function_exists('upload_file_to_temp') 
                                        ? '<span class="badge bg-success">✓ Available</span>' 
                                        : '<span class="badge bg-danger">✗ Missing</span>';
                                    ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Diagnostic Tools -->
        <div class="card mb-4" style="border-left: 4px solid #007bff;">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i data-feather="tool" class="icon"></i> Diagnostic Tools</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="card h-100">
                            <div class="card-body text-center">
                                <i data-feather="activity" class="icon" style="width: 48px; height: 48px; color: #28a745;"></i>
                                <h5 class="mt-3">Live Debug</h5>
                                <p class="text-muted small">Real-time file upload debugging with detailed logs</p>
                                <a href="<?php echo get_uri('team_verification/live_debug'); ?>" class="btn btn-success w-100">
                                    <i data-feather="play-circle" class="icon"></i> Open Live Debug
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card h-100">
                            <div class="card-body text-center">
                                <i data-feather="folder" class="icon" style="width: 48px; height: 48px; color: #007bff;"></i>
                                <h5 class="mt-3">File System Check</h5>
                                <p class="text-muted small">Verify folder permissions and structure</p>
                                <button onclick="checkFileSystem()" class="btn btn-primary w-100">
                                    <i data-feather="check-circle" class="icon"></i> Run Check
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card h-100">
                            <div class="card-body text-center">
                                <i data-feather="database" class="icon" style="width: 48px; height: 48px; color: #ffc107;"></i>
                                <h5 class="mt-3">Database Check</h5>
                                <p class="text-muted small">Verify database schema and integrity</p>
                                <button onclick="checkDatabase()" class="btn btn-warning w-100">
                                    <i data-feather="search" class="icon"></i> Check Database
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detailed Paths -->
        <div class="card mb-4" style="border-left: 4px solid #6c757d;">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i data-feather="folder" class="icon"></i> Storage Paths</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm table-bordered">
                    <thead>
                        <tr>
                            <th>Path</th>
                            <th>Location</th>
                            <th>Status</th>
                            <th>Permissions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Temp Files</strong></td>
                            <td><code><?php echo get_setting("temp_file_path"); ?></code></td>
                            <td>
                                <?php 
                                $temp_path = get_setting("temp_file_path");
                                echo (is_dir($temp_path) && is_writable($temp_path)) 
                                    ? '<span class="badge bg-success">OK</span>' 
                                    : '<span class="badge bg-danger">FAIL</span>';
                                ?>
                            </td>
                            <td>
                                <?php 
                                echo is_dir($temp_path) ? substr(sprintf('%o', fileperms($temp_path)), -4) : 'N/A';
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Verification Storage</strong></td>
                            <td><code><?php echo PLUGINPATH . 'Team_Verification/assets/verification/users/'; ?></code></td>
                            <td>
                                <?php 
                                $base_path = PLUGINPATH . 'Team_Verification/assets/verification/users/';
                                echo (is_dir($base_path) && is_writable($base_path)) 
                                    ? '<span class="badge bg-success">OK</span>' 
                                    : '<span class="badge bg-danger">FAIL</span>';
                                ?>
                            </td>
                            <td>
                                <?php 
                                echo is_dir($base_path) ? substr(sprintf('%o', fileperms($base_path)), -4) : 'N/A';
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Pending Folder</strong></td>
                            <td><code><?php echo PLUGINPATH . 'Team_Verification/assets/verification/users/pending/'; ?></code></td>
                            <td>
                                <?php 
                                $pending_path = PLUGINPATH . 'Team_Verification/assets/verification/users/pending/';
                                echo (is_dir($pending_path) && is_writable($pending_path)) 
                                    ? '<span class="badge bg-success">OK</span>' 
                                    : '<span class="badge bg-danger">FAIL</span>';
                                ?>
                            </td>
                            <td>
                                <?php 
                                echo is_dir($pending_path) ? substr(sprintf('%o', fileperms($pending_path)), -4) : 'N/A';
                                ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="alert alert-info mt-3">
                    <strong>Note:</strong> Folders should have permissions 0755 or 0777 to allow file uploads. If any show "FAIL", you may need to adjust folder permissions via SSH.
                </div>
            </div>
        </div>

        <!-- Maintenance Actions -->
        <div class="card" style="border-left: 4px solid #dc3545;">
            <div class="card-header bg-light">
                <h5 class="mb-0"><i data-feather="shield" class="icon"></i> Maintenance</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <h6>Clear Route Cache</h6>
                        <p class="text-muted small">If routes are not working (404 errors), clear the route cache</p>
                        <button onclick="clearRouteCache()" class="btn btn-info">
                            <i data-feather="refresh-cw" class="icon"></i> Clear Route Cache
                        </button>
                    </div>
                    <div class="col-md-6 mb-3">
                        <h6>Clear Debug Logs</h6>
                        <p class="text-muted small">Clear all debug logs created by the Live Debug tool</p>
                        <button onclick="clearDebugLogs()" class="btn btn-warning">
                            <i data-feather="trash-2" class="icon"></i> Clear Debug Logs
                        </button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<div id="resultModal" class="modal fade" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Diagnostic Results</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="modalBody"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
function checkFileSystem() {
    appAlert.success("Running file system check...", {duration: 2000});
    
    $.ajax({
        url: "<?php echo get_uri('team_verification/check_filesystem'); ?>",
        type: 'POST',
        dataType: 'json',
        success: function(result) {
            if (result.success) {
                $('#modalBody').html('<pre>' + result.report + '</pre>');
                $('#resultModal').modal('show');
            } else {
                appAlert.error(result.message || "Check failed");
            }
        },
        error: function() {
            appAlert.error("Error running file system check");
        }
    });
}

function checkDatabase() {
    appAlert.success("Running database check...", {duration: 2000});
    
    $.ajax({
        url: "<?php echo get_uri('team_verification/check_database'); ?>",
        type: 'POST',
        dataType: 'json',
        success: function(result) {
            if (result.success) {
                $('#modalBody').html('<pre>' + result.report + '</pre>');
                $('#resultModal').modal('show');
            } else {
                appAlert.error(result.message || "Check failed");
            }
        },
        error: function() {
            appAlert.error("Error running database check");
        }
    });
}

function clearRouteCache() {
    if (confirm("Clear route cache? You may need to reload the page after this.")) {
        $.ajax({
            url: "<?php echo get_uri('team_verification/clear_route_cache'); ?>",
            type: 'POST',
            dataType: 'json',
            success: function(result) {
                if (result.success) {
                    appAlert.success("Route cache cleared! Reload the page to see changes.");
                } else {
                    appAlert.error(result.message || "Failed to clear cache");
                }
            }
        });
    }
}

function clearDebugLogs() {
    if (confirm("Clear all debug logs?")) {
        $.ajax({
            url: "<?php echo get_uri('team_verification/clear_debug_logs'); ?>",
            type: 'POST',
            dataType: 'json',
            success: function(result) {
                if (result.success) {
                    appAlert.success("Debug logs cleared!");
                } else {
                    appAlert.error(result.message || "Failed to clear logs");
                }
            }
        });
    }
}

// Initialize feather icons
if (typeof feather !== 'undefined') {
    feather.replace();
}
</script>
