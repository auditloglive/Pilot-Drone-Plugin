<div class="card rounded-bottom">
    <div class="page-title clearfix">
        <h1>
            <i data-feather="shield" class="icon"></i> 
            <?php echo app_lang('team_verification'); ?>
        </h1>
    </div>

    <div class="card-body">
        <!-- Quick Actions - AT TOP -->
        <div class="card mb-4" style="border: 2px solid #28a745;">
            <div class="card-header" style="background: #28a745; color: white;">
                <h4 class="mb-0"><i data-feather="zap" class="icon"></i> Quick Actions</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <a href="<?php echo get_uri('team_verification/instructions'); ?>" class="btn btn-info btn-lg w-100">
                            <i data-feather="book-open" class="icon"></i>
                            Setup Guide
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="<?php echo get_uri('team_verification/list_view'); ?>" class="btn btn-primary btn-lg w-100">
                            <i data-feather="users" class="icon"></i>
                            Manage Team
                        </a>
                    </div>
                    <div class="col-md-3 mb-3">
                        <button onclick="window.location.href='<?php echo get_uri('team_verification/list_view'); ?>?show_backup=1'" class="btn btn-success btn-lg w-100">
                            <i data-feather="database" class="icon"></i>
                            Backup & Restore
                        </button>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="<?php echo get_uri('team_verification/settings'); ?>" class="btn btn-warning btn-lg w-100">
                            <i data-feather="settings" class="icon"></i>
                            Settings & Debug
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Header Section -->
        <div class="bg-primary text-white p-4 rounded mb-4">
            <div class="mb-3">
                <img src="<?php echo base_url('plugins/Team_Verification/assets/images/auditlog-logo-new.png'); ?>" alt="AuditLog VerifyiD" style="height: 60px; width: auto; background: white; padding: 10px; border-radius: 8px;">
            </div>
            <h2 class="mb-2">
                <i data-feather="award" class="icon"></i>
                VerifyiD By AuditLog
            </h2>
            <p class="mb-0" style="font-size: 1.1rem; opacity: 0.9;">
                Version 2.2.0 | Build: 2025-11-10 | Team Member Verification & Public Directory
            </p>
        </div>

        <!-- Statistics Section -->
        <div class="row mb-4">
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <h1 class="mb-2"><?php echo count(array_filter($team_members, function($m) { 
                            return $m->user_status === 'active' && $m->dbs_status === 'verified'; 
                        })); ?></h1>
                        <p class="mb-0">Authorized Members</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center">
                        <h1 class="mb-2"><?php echo count(array_filter($team_members, function($m) { 
                            return $m->dbs_status === 'pending'; 
                        })); ?></h1>
                        <p class="mb-0">Pending Verification</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <h1 class="mb-2"><?php echo count(array_filter($team_members, function($m) { 
                            return $m->public_visibility == 1; 
                        })); ?></h1>
                        <p class="mb-0">Public Visible</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="card bg-secondary text-white">
                    <div class="card-body text-center">
                        <h1 class="mb-2"><?php echo count($team_members); ?></h1>
                        <p class="mb-0">Total Members</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Live Preview Section -->
        <div class="card mb-4" style="border: 2px solid #667eea;">
            <div class="card-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                <h4 class="mb-0"><i data-feather="eye" class="icon"></i> Live Public Directory Preview</h4>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-12 text-center">
                        <p class="text-muted mb-3">Preview what your public visitors will see</p>
                        <div class="btn-group mb-3" role="group">
                            <a href="<?php echo base_url('index.php/public_team'); ?>" target="_blank" class="btn btn-success btn-lg">
                                <i data-feather="external-link" class="icon"></i>
                                Open in New Tab
                            </a>
                            <button onclick="copyPublicUrl()" class="btn btn-info btn-lg">
                                <i data-feather="copy" class="icon"></i>
                                Copy URL
                            </button>
                        </div>
                    </div>
                </div>
                <div style="border: 3px solid #667eea; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
                    <div style="background: #f8f9fa; padding: 8px; border-bottom: 2px solid #667eea; display: flex; align-items: center;">
                        <div style="display: flex; gap: 6px; margin-right: 12px;">
                            <span style="width: 12px; height: 12px; background: #ff5f57; border-radius: 50%;"></span>
                            <span style="width: 12px; height: 12px; background: #ffbd2e; border-radius: 50%;"></span>
                            <span style="width: 12px; height: 12px; background: #28ca42; border-radius: 50%;"></span>
                        </div>
                        <div style="flex: 1; background: white; padding: 4px 12px; border-radius: 4px; font-size: 12px; color: #666;">
                            <?php echo base_url('index.php/public_team'); ?>
                        </div>
                    </div>
                    <iframe 
                        src="<?php echo base_url('index.php/public_team'); ?>" 
                        style="width: 100%; height: 600px; border: none; display: block;"
                        title="Public Directory Preview">
                    </iframe>
                </div>
            </div>
        </div>


        <!-- Features Overview -->
        <div class="card mb-4">
            <div class="card-header">
                <h4 class="mb-0"><i data-feather="check-circle" class="icon"></i> System Features</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3 p-3 bg-light rounded">
                            <i data-feather="shield" class="icon text-primary"></i>
                            <strong>DBS Verification Tracking</strong>
                            <p class="mb-0 mt-2 text-muted">Track DBS certificates, issue dates, and expiry dates for all team members</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3 p-3 bg-light rounded">
                            <i data-feather="globe" class="icon text-success"></i>
                            <strong>Public Directory</strong>
                            <p class="mb-0 mt-2 text-muted">Public-facing team member directory with verification status display</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3 p-3 bg-light rounded">
                            <i data-feather="credit-card" class="icon text-info"></i>
                            <strong>ID Card Generation</strong>
                            <p class="mb-0 mt-2 text-muted">Professional ID cards with UID numbers (Badgy 100 printer compatible)</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3 p-3 bg-light rounded">
                            <i data-feather="lock" class="icon text-warning"></i>
                            <strong>UUID Secure URLs</strong>
                            <p class="mb-0 mt-2 text-muted">Privacy-friendly profile URLs using UUIDs instead of database IDs</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3 p-3 bg-light rounded">
                            <i data-feather="maximize" class="icon text-danger"></i>
                            <strong>QR Code Profiles</strong>
                            <p class="mb-0 mt-2 text-muted">Generate QR codes for instant profile sharing and verification</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3 p-3 bg-light rounded">
                            <i data-feather="database" class="icon text-secondary"></i>
                            <strong>Data Preservation</strong>
                            <p class="mb-0 mt-2 text-muted">10-year retention for inactive accounts, permanent for active users</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Public URLs Section -->
        <div class="card mb-4">
            <div class="card-header bg-info text-white">
                <h4 class="mb-0"><i data-feather="link" class="icon"></i> Public Access URLs</h4>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label"><strong>Public Directory:</strong></label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="publicDirUrl" value="<?php echo base_url('index.php/public_team'); ?>" readonly>
                        <button class="btn btn-outline-secondary" onclick="copyToClipboard('publicDirUrl')">
                            <i data-feather="copy" class="icon"></i> Copy
                        </button>
                    </div>
                </div>
                <div class="mb-0">
                    <label class="form-label"><strong>Example Profile URL:</strong></label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="exampleUrl" value="<?php echo base_url('index.php/public_team/profile/MEMBER-UUID-HERE'); ?>" readonly>
                        <button class="btn btn-outline-secondary" onclick="copyToClipboard('exampleUrl')">
                            <i data-feather="copy" class="icon"></i> Copy
                        </button>
                    </div>
                    <small class="text-muted">Replace MEMBER-UUID-HERE with actual member UUID from team verification list</small>
                </div>
            </div>
        </div>

        <!-- Installation Status -->
        <div class="alert alert-success mb-0">
            <h5><i data-feather="check-circle" class="icon"></i> Plugin Status</h5>
            <p class="mb-0">
                <strong>✓ Plugin Installed:</strong> VerifyiD By AuditLog v2.1.0<br>
                <strong>✓ Database:</strong> Connected and operational<br>
                <strong>✓ Public Routes:</strong> Available at <code>/index.php/public_team</code><br>
                <strong>✓ Total Members:</strong> <?php echo count($team_members); ?> in system
            </p>
        </div>
    </div>
</div>

<script>
function copyToClipboard(elementId) {
    const input = document.getElementById(elementId);
    input.select();
    document.execCommand('copy');
    appAlert.success('URL copied to clipboard!');
}

function copyPublicUrl() {
    copyToClipboard('publicDirUrl');
}

// Initialize Feather icons
if (typeof feather !== 'undefined') {
    feather.replace();
}
</script>
