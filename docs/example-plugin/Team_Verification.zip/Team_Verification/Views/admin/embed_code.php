<div class="card rounded-bottom">
    <div class="page-title clearfix">
        <h1>
            <i data-feather="code" class="icon"></i> 
            Custom Page Embed Code
        </h1>
        <div class="title-button-group">
            <a href="<?php echo get_uri('team_verification'); ?>" class="btn btn-default">
                <i data-feather="arrow-left" class="icon"></i> Back to Dashboard
            </a>
        </div>
    </div>

    <div class="card-body">
        <?php if (isset($embed_type) && $embed_type === 'public_directory') { ?>
        <div class="alert alert-info mb-3">
            <h5><i data-feather="monitor" class="icon"></i> Public Directory Embed</h5>
            <p class="mb-0">This embed code displays the live team verification directory using an iframe. All interactions (search, profile viewing, QR codes) work within the embedded view.</p>
        </div>
        <?php } else { ?>
        <div class="alert alert-success mb-3">
            <h5><i data-feather="check-circle" class="icon"></i> Updated: Inline Styles Version</h5>
            <p class="mb-0">This version works with Rise CRM! All styles are inline (no &lt;style&gt; tags that get stripped).</p>
        </div>
        <?php } ?>
        
        <div class="alert alert-info mb-4">
            <h5><i data-feather="info" class="icon"></i> How to Use This Embed Code</h5>
            <ol class="mb-0" style="padding-left: 20px;">
                <li>Click the <strong>"Copy Embed Code"</strong> button below</li>
                <li>Go to <strong>Settings → Custom Pages</strong> in Rise CRM</li>
                <li>Create or edit a custom page</li>
                <li>Paste the embed code into the page editor</li>
                <li>Save the page</li>
            </ol>
        </div>

        <div class="card bg-light mb-3">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i data-feather="code" class="icon"></i> Embed Code</h5>
                <button onclick="copyEmbedCode()" class="btn btn-light btn-sm">
                    <i data-feather="copy" class="icon"></i> Copy Embed Code
                </button>
            </div>
            <div class="card-body p-0">
                <textarea id="embedCode" readonly style="width: 100%; height: 500px; font-family: 'Courier New', monospace; font-size: 12px; padding: 15px; border: none; resize: vertical;"><?php echo htmlspecialchars($embed_code); ?></textarea>
            </div>
        </div>

        <div class="alert alert-warning">
            <h5><i data-feather="alert-triangle" class="icon"></i> Important Setup Step</h5>
            <p><strong>Upload the plugin package to your server:</strong></p>
            <p class="mb-2">Make sure <code>AuditLog_Public_Team_Standalone_v2.1.0.zip</code> is uploaded to:</p>
            <pre class="bg-dark text-white p-2 rounded">/plugins_update/AuditLog-VerifyiD/AuditLog_Public_Team_Standalone_v2.1.0.zip</pre>
            <p class="mb-0">So the download button works at:<br>
            <code>https://management.omniex.uk/plugins_update/AuditLog-VerifyiD/AuditLog_Public_Team_Standalone_v2.1.0.zip</code></p>
        </div>

        <div class="card">
            <div class="card-header">
                <h5><i data-feather="link" class="icon"></i> Your Custom Page URL</h5>
            </div>
            <div class="card-body">
                <div class="input-group">
                    <input type="text" class="form-control" id="customPageUrl" value="https://management.omniex.uk/index.php/about/auditlog-verifyid_build" readonly>
                    <button class="btn btn-outline-secondary" onclick="copyToClipboard('customPageUrl')">
                        <i data-feather="copy" class="icon"></i> Copy URL
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyEmbedCode() {
    const embedCode = document.getElementById('embedCode');
    embedCode.select();
    document.execCommand('copy');
    appAlert.success('Embed code copied to clipboard! You can now paste it into your custom page editor.');
}

function copyToClipboard(elementId) {
    const input = document.getElementById(elementId);
    input.select();
    document.execCommand('copy');
    appAlert.success('URL copied to clipboard!');
}

if (typeof feather !== 'undefined') {
    feather.replace();
}
</script>
