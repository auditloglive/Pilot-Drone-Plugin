<!-- Quick Navigation Bar -->
<div class="card mb-3" style="border-left: 4px solid #667eea;">
    <div class="card-body py-2">
        <div class="d-flex flex-wrap gap-2">
            <a href="<?php echo get_uri('team_verification/list_view'); ?>" class="btn btn-sm btn-primary">
                <i class="fa fa-users"></i> Team List
            </a>
            <a href="<?php echo get_uri('team_verification/public_directory'); ?>" class="btn btn-sm btn-info" target="_blank">
                <i class="fa fa-globe"></i> Public Directory
            </a>
            <a href="<?php echo get_uri('team_verification/list_view?show_backup=1'); ?>" class="btn btn-sm btn-success">
                <i class="fa fa-database"></i> Backup & Restore
            </a>
            <a href="<?php echo get_uri('team_verification/settings'); ?>" class="btn btn-sm btn-warning">
                <i class="fa fa-cog"></i> Settings & Debug
            </a>
            <a href="<?php echo get_uri('team_verification/live_debug'); ?>" class="btn btn-sm btn-secondary">
                <i class="fa fa-bug"></i> Live Logs
            </a>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h4>Live Debug - File Upload Diagnostics</h4>
    </div>
    <div class="card-body">
        <div class="alert alert-info">
            <strong>Instructions:</strong> Keep this page open, then try uploading a file in another tab. Refresh this page to see what happened.
        </div>

        <h5>Latest Upload Attempts:</h5>
        <div id="debug-log" style="background: #f5f5f5; padding: 15px; border-radius: 5px; max-height: 500px; overflow-y: auto; font-family: monospace; font-size: 12px; white-space: pre-wrap;">
            <?php
            $debug_file = PLUGINPATH . 'Team_Verification/assets/verification/debug.log';
            if (file_exists($debug_file)) {
                $logs = file_get_contents($debug_file);
                // Show latest 100 lines
                $lines = explode("\n", $logs);
                $lines = array_slice($lines, -100);
                echo htmlspecialchars(implode("\n", $lines));
            } else {
                echo "No debug logs yet. Try uploading a file.\n\n";
                echo "Log file location: " . $debug_file;
            }
            ?>
        </div>

        <div class="mt-3">
            <button onclick="location.reload()" class="btn btn-primary">
                <i class="fa fa-refresh"></i> Refresh Logs
            </button>
            <button onclick="clearLogs()" class="btn btn-danger">
                <i class="fa fa-trash"></i> Clear Logs
            </button>
        </div>

        <h5 class="mt-4">System Check:</h5>
        <table class="table table-bordered">
            <tr>
                <th>Check</th>
                <th>Status</th>
                <th>Details</th>
            </tr>
            <tr>
                <td>Temp Folder</td>
                <td><?php 
                    $temp_path = get_setting("temp_file_path");
                    echo (is_dir($temp_path) && is_writable($temp_path)) ? '<span class="badge bg-success">OK</span>' : '<span class="badge bg-danger">FAIL</span>';
                ?></td>
                <td><?php echo $temp_path; ?></td>
            </tr>
            <tr>
                <td>Base Folder</td>
                <td><?php 
                    $base_path = PLUGINPATH . 'Team_Verification/assets/verification/users/';
                    echo (is_dir($base_path) && is_writable($base_path)) ? '<span class="badge bg-success">OK</span>' : '<span class="badge bg-danger">FAIL</span>';
                ?></td>
                <td><?php echo $base_path; ?></td>
            </tr>
            <tr>
                <td>Pending Folder</td>
                <td><?php 
                    $pending_path = PLUGINPATH . 'Team_Verification/assets/verification/users/pending/';
                    echo (is_dir($pending_path) && is_writable($pending_path)) ? '<span class="badge bg-success">OK</span>' : '<span class="badge bg-danger">FAIL</span>';
                ?></td>
                <td><?php echo $pending_path; ?></td>
            </tr>
            <tr>
                <td>Upload Function</td>
                <td><?php echo function_exists('upload_file_to_temp') ? '<span class="badge bg-success">EXISTS</span>' : '<span class="badge bg-danger">MISSING</span>'; ?></td>
                <td>Rise CRM upload handler</td>
            </tr>
        </table>
    </div>
</div>

<script>
function clearLogs() {
    if (confirm('Clear all debug logs?')) {
        $.ajax({
            url: "<?php echo get_uri('team_verification/clear_debug_logs'); ?>",
            type: 'POST',
            success: function() {
                location.reload();
            }
        });
    }
}
</script>
