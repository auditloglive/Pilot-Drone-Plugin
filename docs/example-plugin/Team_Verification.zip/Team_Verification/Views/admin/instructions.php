<div class="card">
    <div class="card-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
        <h4 style="margin: 0;"><i data-feather="book-open" style="width: 24px; height: 24px; vertical-align: middle;"></i> VerifyiD By AuditLog - Setup & Usage Instructions</h4>
    </div>
    <div class="card-body">
        
        <div class="text-center mb-4">
            <img src="<?php echo base_url('plugins/Team_Verification/assets/images/auditlog-logo-new.png'); ?>" alt="AuditLog VerifyiD" style="height: 80px; width: auto; background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        </div>
        
        <div class="mb-4 p-3" style="background: #e7f3ff; border-left: 4px solid #2196F3; border-radius: 4px;">
            <h5 style="margin: 0 0 10px 0; color: #1976D2;"><i data-feather="check-circle" style="width: 20px; height: 20px;"></i> Installation Complete!</h5>
            <p style="margin: 0;">The VerifyiD By AuditLog plugin is installed and ready to use. Follow the steps below to get started.</p>
        </div>

        <hr>

        <h4 class="mb-3"><i data-feather="settings" style="width: 20px; height: 20px;"></i> Quick Start Guide</h4>

        <div class="accordion" id="instructionsAccordion">
            
            <!-- Step 1 -->
            <div class="card mb-2">
                <div class="card-header" id="heading1" style="background: #f8f9fa; cursor: pointer;" data-bs-toggle="collapse" data-bs-target="#collapse1">
                    <h5 class="mb-0">
                        <span class="badge bg-primary">1</span> Add Team Members to Verification System
                    </h5>
                </div>
                <div id="collapse1" class="collapse show" data-bs-parent="#instructionsAccordion">
                    <div class="card-body">
                        <ol>
                            <li>Go to <strong>Team Verification</strong> from the left menu</li>
                            <li>Click <strong>"Add Verification"</strong> button</li>
                            <li>Select a team member from the dropdown</li>
                            <li>Upload their photo (required for public display)</li>
                            <li>Enter DBS certificate details:
                                <ul>
                                    <li>Certificate Number</li>
                                    <li>Issue Date</li>
                                    <li>Expiry Date</li>
                                    <li>Upload DBS certificate document (optional)</li>
                                </ul>
                            </li>
                            <li>Assign a unique <strong>UID Card Number</strong> (for ID badge printing)</li>
                            <li>Set <strong>Public Visibility</strong> to "Yes" to show on public directory</li>
                            <li>Click <strong>Save</strong></li>
                        </ol>
                        <div class="alert alert-info mb-0">
                            <i data-feather="info" style="width: 16px; height: 16px;"></i> <strong>Note:</strong> Only team members with "Active" status AND "Verified" DBS status will show as AUTHORIZED on the public directory.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 2 -->
            <div class="card mb-2">
                <div class="card-header" id="heading2" style="background: #f8f9fa; cursor: pointer;" data-bs-toggle="collapse" data-bs-target="#collapse2">
                    <h5 class="mb-0">
                        <span class="badge bg-primary">2</span> Public Directory Access
                    </h5>
                </div>
                <div id="collapse2" class="collapse" data-bs-parent="#instructionsAccordion">
                    <div class="card-body">
                        <h6>Your Public Directory URLs:</h6>
                        <div class="p-3 mb-3" style="background: #f8f9fa; border-radius: 4px; font-family: monospace;">
                            <strong>Directory:</strong><br>
                            <?php echo get_uri("public_team"); ?><br><br>
                            <strong>Individual Profile:</strong><br>
                            <?php echo get_uri("public_team/profile/{uuid}"); ?>
                        </div>
                        <p><strong>Features:</strong></p>
                        <ul>
                            <li>✅ No login required - publicly accessible</li>
                            <li>✅ Shows only team members with Public Visibility enabled</li>
                            <li>✅ Displays authorization status (Active + DBS Verified = AUTHORIZED)</li>
                            <li>✅ QR codes automatically generated for each profile</li>
                            <li>✅ Unauthorized member reporting with automatic ticket creation</li>
                        </ul>
                        <a href="<?php echo get_uri("public_team"); ?>" target="_blank" class="btn btn-primary">
                            <i data-feather="external-link" style="width: 16px; height: 16px;"></i> View Public Directory
                        </a>
                    </div>
                </div>
            </div>

            <!-- Step 3 -->
            <div class="card mb-2">
                <div class="card-header" id="heading3" style="background: #f8f9fa; cursor: pointer;" data-bs-toggle="collapse" data-bs-target="#collapse3">
                    <h5 class="mb-0">
                        <span class="badge bg-primary">3</span> Embed in Custom Pages
                    </h5>
                </div>
                <div id="collapse3" class="collapse" data-bs-parent="#instructionsAccordion">
                    <div class="card-body">
                        <p>You can embed the team directory inside Rise CRM custom pages for quick internal viewing:</p>
                        <ol>
                            <li>Go to <strong>Team Verification Dashboard</strong></li>
                            <li>Click <strong>"Directory Embed"</strong> button</li>
                            <li>Copy the embed code</li>
                            <li>Go to <strong>Settings</strong> → <strong>Custom Pages</strong></li>
                            <li>Create or edit a custom page</li>
                            <li>Paste the embed code</li>
                            <li>Save</li>
                        </ol>
                        <div class="alert alert-warning mb-0">
                            <i data-feather="alert-triangle" style="width: 16px; height: 16px;"></i> <strong>Important:</strong> The embedded directory uses modal popups to show profiles (Rise CRM blocks iframes). QR codes always link to the public URLs for external sharing.
                        </div>
                    </div>
                </div>
            </div>

            <!-- Step 4 -->
            <div class="card mb-2">
                <div class="card-header" id="heading4" style="background: #f8f9fa; cursor: pointer;" data-bs-toggle="collapse" data-bs-target="#collapse4">
                    <h5 class="mb-0">
                        <span class="badge bg-primary">4</span> ID Card Printing (Badgy 100 Compatible)
                    </h5>
                </div>
                <div id="collapse4" class="collapse" data-bs-parent="#instructionsAccordion">
                    <div class="card-body">
                        <p><strong>Print professional ID cards with QR codes:</strong></p>
                        <ol>
                            <li>Go to <strong>Team Verification</strong> list</li>
                            <li>Click on a team member's name</li>
                            <li>Click <strong>"View ID Card"</strong> button</li>
                            <li>The ID card preview will open showing:
                                <ul>
                                    <li>Photo</li>
                                    <li>Name and job title</li>
                                    <li>UID Card Number</li>
                                    <li>Authorization status badge</li>
                                    <li>QR code linking to public profile</li>
                                </ul>
                            </li>
                            <li>Print directly or save as PDF</li>
                        </ol>
                        <p><strong>BadgeStudio CSV Export:</strong></p>
                        <p>Coming soon - bulk export to CSV format compatible with Evolis BadgeStudio software for batch printing.</p>
                    </div>
                </div>
            </div>

            <!-- Step 5 -->
            <div class="card mb-2">
                <div class="card-header" id="heading5" style="background: #f8f9fa; cursor: pointer;" data-bs-toggle="collapse" data-bs-target="#collapse5">
                    <h5 class="mb-0">
                        <span class="badge bg-primary">5</span> Managing Unauthorized Reports
                    </h5>
                </div>
                <div id="collapse5" class="collapse" data-bs-parent="#instructionsAccordion">
                    <div class="card-body">
                        <p>When someone reports an unauthorized team member from the public directory:</p>
                        <ol>
                            <li>A ticket is automatically created in your <strong>Tickets</strong> system</li>
                            <li>Ticket includes:
                                <ul>
                                    <li>Team member details</li>
                                    <li>Reporter information (name, email, phone)</li>
                                    <li>Reason for report</li>
                                    <li>Direct link to the profile</li>
                                </ul>
                            </li>
                            <li>Tagged with label: <code>unauthorized-report</code></li>
                            <li>You can respond to the reporter via the ticket system</li>
                            <li>Take action: update DBS status, deactivate user, or investigate</li>
                        </ol>
                    </div>
                </div>
            </div>

        </div>

        <hr class="my-4">

        <h4 class="mb-3"><i data-feather="shield" style="width: 20px; height: 20px;"></i> Authorization Logic</h4>
        
        <div class="row">
            <div class="col-md-6">
                <div class="card bg-success text-white mb-3">
                    <div class="card-body">
                        <h5 class="card-title">✓ AUTHORIZED</h5>
                        <p class="card-text mb-0">
                            • User Status = "Active"<br>
                            • DBS Status = "Verified"<br>
                            • Public Visibility = "Yes"
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-danger text-white mb-3">
                    <div class="card-body">
                        <h5 class="card-title">✗ NOT AUTHORIZED</h5>
                        <p class="card-text mb-0">
                            • User Status = "Inactive" OR<br>
                            • DBS Status ≠ "Verified" OR<br>
                            • Public Visibility = "No"
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <hr class="my-4">

        <h4 class="mb-3"><i data-feather="help-circle" style="width: 20px; height: 20px;"></i> Frequently Asked Questions</h4>

        <div class="mb-3">
            <strong>Q: Can the public see all team members?</strong><br>
            A: No, only team members with "Public Visibility" set to "Yes" appear on the public directory.
        </div>

        <div class="mb-3">
            <strong>Q: What happens if I deactivate a user in Rise CRM?</strong><br>
            A: They will automatically show as "NOT AUTHORIZED" on the public directory, even if their DBS is verified.
        </div>

        <div class="mb-3">
            <strong>Q: How do I remove someone from the public directory?</strong><br>
            A: Either set their "Public Visibility" to "No" or set their Rise CRM user status to "Inactive".
        </div>

        <div class="mb-3">
            <strong>Q: Are the public URLs secure?</strong><br>
            A: Yes, profiles use UUID-based URLs (random 36-character identifiers) instead of predictable user IDs for privacy.
        </div>

        <div class="mb-3">
            <strong>Q: Can I customize the public directory appearance?</strong><br>
            A: The public views are in <code>plugins/Team_Verification/Views/public/</code> and can be customized with your branding.
        </div>

        <hr class="my-4">

        <div class="text-center">
            <h5>Ready to Get Started?</h5>
            <a href="<?php echo get_uri("team_verification"); ?>" class="btn btn-primary btn-lg me-2">
                <i data-feather="users" style="width: 20px; height: 20px;"></i> Manage Team Verification
            </a>
            <a href="<?php echo get_uri("public_team"); ?>" target="_blank" class="btn btn-outline-primary btn-lg">
                <i data-feather="external-link" style="width: 20px; height: 20px;"></i> View Public Directory
            </a>
        </div>

    </div>
</div>

<script>
    $(document).ready(function() {
        feather.replace();
    });
</script>
