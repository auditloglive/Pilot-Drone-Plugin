<?php if (isset($_GET['show_backup']) && $_GET['show_backup'] == 1) {
    // Show backup page instead
    include(__DIR__ . '/backup.php');
    return;
} ?>

<?php if (isset($custom_css)) { echo $custom_css; } ?>

<style>
/* Force proper avatar sizing - inline styles as fallback */
.admin-avatar {
    width: 60px !important;
    height: 60px !important;
    min-width: 60px !important;
    min-height: 60px !important;
    max-width: 60px !important;
    max-height: 60px !important;
    border-radius: 50% !important;
    object-fit: cover !important;
    object-position: center !important;
    border: 3px solid #e9ecef !important;
    display: block !important;
    flex-shrink: 0 !important;
    overflow: hidden !important;
}
.admin-avatar-placeholder {
    width: 60px !important;
    height: 60px !important;
    min-width: 60px !important;
    min-height: 60px !important;
    max-width: 60px !important;
    max-height: 60px !important;
    border-radius: 50% !important;
    flex-shrink: 0 !important;
}
</style>

<!-- Quick Navigation Bar -->
<div class="card mb-4" style="border-left: 4px solid #667eea;">
    <div class="card-body py-2">
        <div class="d-flex flex-wrap gap-2">
            <a href="<?php echo get_uri('team_verification/list_view'); ?>" class="btn btn-sm btn-primary">
                <i class="fa fa-users"></i> Team List
            </a>
            <a href="<?php echo get_uri('team_verification/public_directory'); ?>" class="btn btn-sm btn-info" target="_blank">
                <i class="fa fa-globe"></i> Public Directory
            </a>
            <a href="<?php echo get_uri('team_verification/list_view?show_backup=1'); ?>" class="btn btn-sm btn-success">
                <i class="fa fa-database"></i> Backup & Restore
            </a>
            <a href="<?php echo get_uri('team_verification/settings'); ?>" class="btn btn-sm btn-warning">
                <i class="fa fa-cog"></i> Settings & Debug
            </a>
            <a href="<?php echo get_uri('team_verification/live_debug'); ?>" class="btn btn-sm btn-secondary">
                <i class="fa fa-bug"></i> Live Logs
            </a>
        </div>
    </div>
</div>

<div class="mb-4">
    <h4><?php echo app_lang('tv_team_verification_management'); ?></h4>
</div>

<!-- Admin Search Box -->
<div class="row mb-4">
    <div class="col-md-12">
        <div class="input-group">
            <span class="input-group-text">
                <i class="fa fa-search"></i>
            </span>
            <input type="text" id="adminTeamSearch" class="form-control" placeholder="<?php echo app_lang('search'); ?> by name, email, or job title...">
        </div>
    </div>
</div>

<div class="row" id="teamMemberCards">
    <?php foreach ($users as $user) { 
        $verification = isset($verification_data[$user->id]) ? $verification_data[$user->id] : null;
        $dbs_status = ($verification && isset($verification->dbs_status)) ? $verification->dbs_status : 'pending';
        $uid_card_number = ($verification && isset($verification->uid_card_number) && $verification->uid_card_number) ? $verification->uid_card_number : '-';
        $public_visibility = ($verification && isset($verification->public_visibility) && $verification->public_visibility) ? app_lang('yes') : app_lang('no');
        $updated_at = ($verification && isset($verification->updated_at) && $verification->updated_at) ? format_to_date($verification->updated_at, false) : '-';
        
        $status_badge_class = array(
            'verified' => 'bg-success',
            'pending' => 'bg-warning',
            'expired' => 'bg-danger',
            'rejected' => 'bg-secondary'
        );
        $badge_class = isset($status_badge_class[$dbs_status]) ? $status_badge_class[$dbs_status] : 'bg-secondary';
        
        $visibility_icon = ($verification && isset($verification->public_visibility) && $verification->public_visibility) ? 'eye' : 'eye-slash';
        $visibility_class = ($verification && isset($verification->public_visibility) && $verification->public_visibility) ? 'text-success' : 'text-muted';
    ?>
    <div class="col-md-6 col-lg-4 mb-4">
        <div class="admin-team-card">
            <div class="card-member-header">
                <div class="d-flex align-items-center mb-3">
                    <?php 
                    // Show VERIFICATION photo (not Rise CRM profile image) using helper function
                    $verification_photo_url = '';
                    if ($verification) {
                        $verification_photo_url = get_verification_photo_url($verification, $user->id);
                    }
                    
                    if ($verification_photo_url) { ?>
                        <img src="<?php echo $verification_photo_url; ?>" class="admin-avatar me-3" alt="<?php echo $user->first_name . ' ' . $user->last_name; ?>">
                    <?php } else { ?>
                        <div class="admin-avatar-placeholder me-3">
                            <i class="fa fa-user"></i>
                        </div>
                    <?php } ?>
                    <div class="flex-grow-1">
                        <h5 class="mb-0"><?php echo $user->first_name . ' ' . $user->last_name; ?></h5>
                        <small class="text-muted"><?php echo $user->email; ?></small>
                    </div>
                </div>
            </div>
            
            <div class="card-member-body">
                <div class="info-row">
                    <span class="info-label"><i class="fa fa-briefcase"></i> <?php echo app_lang('tv_job_title'); ?>:</span>
                    <span class="info-value"><?php echo $user->job_title ? $user->job_title : '-'; ?></span>
                </div>
                
                <div class="info-row">
                    <span class="info-label"><i class="fa fa-id-card"></i> <?php echo app_lang('tv_uid_card_number'); ?>:</span>
                    <span class="info-value"><strong class="text-primary"><?php echo $uid_card_number; ?></strong></span>
                </div>
                
                <div class="info-row">
                    <span class="info-label"><i class="fa fa-shield"></i> <?php echo app_lang('tv_dbs_status'); ?>:</span>
                    <span class="info-value">
                        <span class="badge <?php echo $badge_class; ?>"><?php echo app_lang('tv_status_' . $dbs_status); ?></span>
                    </span>
                </div>
                
                <div class="info-row">
                    <span class="info-label"><i class="fa fa-<?php echo $visibility_icon; ?>"></i> <?php echo app_lang('tv_public_visibility'); ?>:</span>
                    <span class="info-value <?php echo $visibility_class; ?>"><?php echo $public_visibility; ?></span>
                </div>
                
                <div class="info-row">
                    <span class="info-label"><i class="fa fa-clock"></i> <?php echo app_lang('tv_last_updated'); ?>:</span>
                    <span class="info-value"><?php echo $updated_at; ?></span>
                </div>
            </div>
            
            <div class="card-member-footer">
                <a href="<?php echo get_uri('team_verification/manage/' . $user->id); ?>" class="btn btn-primary w-100">
                    <i class="fa fa-edit"></i> <?php echo app_lang('tv_manage'); ?>
                </a>
            </div>
        </div>
    </div>
    <?php } ?>
</div>

<?php if (empty($users)) { ?>
<div class="card">
    <div class="card-body text-center py-5">
        <i class="fa fa-users fa-3x text-muted mb-3"></i>
        <p class="text-muted"><?php echo app_lang('no_record_found'); ?></p>
    </div>
</div>
<?php } ?>

<script>
// Admin search functionality
document.getElementById('adminTeamSearch').addEventListener('keyup', function() {
    const searchTerm = this.value.toLowerCase();
    const memberCards = document.querySelectorAll('.admin-team-card');

    memberCards.forEach(function(card) {
        const cardText = card.textContent.toLowerCase();
        
        if (cardText.includes(searchTerm)) {
            card.closest('.col-md-6').style.display = '';
        } else {
            card.closest('.col-md-6').style.display = 'none';
        }
    });
});
</script>
