<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $user_info->first_name . ' ' . $user_info->last_name; ?> - Team Profile</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f7fa; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 20px; text-align: center; }
        .container { max-width: 900px; margin: 40px auto; padding: 0 20px; }
        .card { background: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .profile-photo { width: 200px; height: 200px; border-radius: 50%; object-fit: cover; margin: 20px auto; display: block; }
        .authorized { background: #28a745; color: white; padding: 20px; text-align: center; border-radius: 10px; margin: 20px 0; }
        .not-authorized { background: #dc3545; color: white; padding: 20px; text-align: center; border-radius: 10px; margin: 20px 0; }
        .info-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 15px 0; }
        .info-label { color: #7f8c8d; font-size: 0.9rem; margin-bottom: 5px; }
        .info-value { font-weight: bold; font-size: 1.1rem; }
        .btn { display: inline-block; padding: 12px 24px; border-radius: 5px; text-decoration: none; margin: 10px 5px; }
        .btn-primary { background: #667eea; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        h1, h2, h3 { margin-bottom: 15px; color: #2c3e50; }
        .text-center { text-align: center; }
    </style>
</head>
<body>
    <div class="header">
        <div style="margin-bottom: 20px;">
            <img src="<?php echo base_url('plugins/Team_Verification/assets/images/auditlog-logo-new.png'); ?>" alt="AuditLog VerifyiD" style="height: 60px; width: auto;">
        </div>
        <h1>Team Member Profile</h1>
    </div>

    <div class="container">
        <div class="card">
            <?php 
            // Use helper function to get photo URL (checks UID folder, pending folder, legacy folder)
            $photo_url = get_verification_photo_url($verification, $verification->user_id);
            
            // Fallback to initials if no photo
            if (empty($photo_url)) {
                $photo_url = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="200" height="200"%3E%3Crect fill="%23667eea" width="200" height="200"/%3E%3Ctext x="50%25" y="50%25" font-size="80" fill="white" text-anchor="middle" dy=".3em"%3E' . strtoupper(substr($user_info->first_name, 0, 1) . substr($user_info->last_name, 0, 1)) . '%3C/text%3E%3C/svg%3E';
            }
            ?>
            <img src="<?php echo $photo_url; ?>" alt="Profile" class="profile-photo" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=&quot;http://www.w3.org/2000/svg&quot; width=&quot;200&quot; height=&quot;200&quot;%3E%3Crect fill=&quot;%23667eea&quot; width=&quot;200&quot; height=&quot;200&quot;/%3E%3Ctext x=&quot;50%25&quot; y=&quot;50%25&quot; font-size=&quot;80&quot; fill=&quot;white&quot; text-anchor=&quot;middle&quot; dy=&quot;.3em&quot;%3E<?php echo strtoupper(substr($user_info->first_name, 0, 1) . substr($user_info->last_name, 0, 1)); ?>%3C/text%3E%3C/svg%3E';">
            
            <div class="text-center">
                <h2><?php echo $user_info->first_name . ' ' . $user_info->last_name; ?></h2>
                <?php if ($user_info->job_title) { ?>
                    <p style="color: #7f8c8d; font-size: 1.1rem; margin-bottom: 20px;"><?php echo $user_info->job_title; ?></p>
                <?php } ?>
            </div>

            <?php if ($is_authorized) { ?>
                <div class="authorized">
                    <h3 style="color: white; margin: 0;">✓ AUTHORIZED</h3>
                    <p style="margin: 10px 0 0 0;">DBS Verified Team Member</p>
                </div>
            <?php } else { ?>
                <div class="not-authorized">
                    <h3 style="color: white; margin: 0;">✗ NOT AUTHORIZED</h3>
                    <p style="margin: 10px 0 0 0;">This team member is not currently authorized</p>
                </div>
            <?php } ?>
        </div>

        <?php if ($verification->uid_card_number) { ?>
        <div class="card">
            <h3>UID Card Number</h3>
            <div style="font-size: 1.5rem; font-weight: bold; color: #667eea; text-align: center; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                <?php echo $verification->uid_card_number; ?>
            </div>
        </div>
        <?php } ?>

        <div class="card">
            <h3>Verification Status</h3>
            <div class="info-row">
                <div>
                    <div class="info-label">DBS Status</div>
                    <div class="info-value"><?php echo ucfirst($verification->dbs_status); ?></div>
                </div>
                <?php if ($verification->dbs_certificate_number) { ?>
                <div>
                    <div class="info-label">Certificate Number</div>
                    <div class="info-value"><?php echo $verification->dbs_certificate_number; ?></div>
                </div>
                <?php } ?>
            </div>
            
            <?php if ($verification->dbs_issue_date || $verification->dbs_expiry_date) { ?>
            <div class="info-row">
                <?php if ($verification->dbs_issue_date) { ?>
                <div>
                    <div class="info-label">Issue Date</div>
                    <div class="info-value"><?php echo date('d M Y', strtotime($verification->dbs_issue_date)); ?></div>
                </div>
                <?php } ?>
                <?php if ($verification->dbs_expiry_date) { ?>
                <div>
                    <div class="info-label">Expiry Date</div>
                    <div class="info-value"><?php echo date('d M Y', strtotime($verification->dbs_expiry_date)); ?></div>
                </div>
                <?php } ?>
            </div>
            <?php } ?>
        </div>

        <div class="card text-center">
            <h3>QR Code</h3>
            <p style="color: #7f8c8d; margin-bottom: 20px;">Scan to view this profile</p>
            <?php 
            $profile_url = base_url('index.php/public_team/profile/' . $verification->uuid);
            $qr_code_url = 'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=' . urlencode($profile_url);
            ?>
            <img src="<?php echo $qr_code_url; ?>" alt="QR Code" style="max-width: 250px; border: 2px solid #eee; padding: 10px;">
        </div>
    </div>
</body>
</html>
