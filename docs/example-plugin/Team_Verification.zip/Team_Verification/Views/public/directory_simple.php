<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authorized Team Members Directory</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f7fa; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 20px; text-align: center; }
        .container { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
        .member-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        .member-card { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); text-align: center; }
        .member-card img { width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin-bottom: 15px; }
        .member-name { font-size: 1.3rem; font-weight: bold; color: #2c3e50; margin-bottom: 5px; }
        .member-title { color: #7f8c8d; margin-bottom: 15px; }
        .badge { display: inline-block; padding: 5px 15px; border-radius: 20px; font-size: 0.9rem; margin: 10px 0; }
        .badge-success { background: #28a745; color: white; }
        .badge-warning { background: #ffc107; color: #000; }
        .badge-danger { background: #dc3545; color: white; }
        .btn { display: inline-block; padding: 10px 20px; border-radius: 5px; text-decoration: none; margin-top: 10px; }
        .btn-primary { background: #667eea; color: white; }
        .alert { background: #e7f3ff; border-left: 4px solid #2196F3; padding: 15px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="header">
        <div style="margin-bottom: 20px;">
            <img src="<?php echo base_url('plugins/Team_Verification/assets/images/auditlog-logo-new.png'); ?>" alt="AuditLog VerifyiD" style="height: 60px; width: auto;">
        </div>
        <h1>Authorized Team Members</h1>
        <p>Verified and authorized team members with DBS certification</p>
    </div>

    <div class="container">
        <?php if (empty($team_members)) { ?>
            <div class="alert">
                No authorized team members are currently available for public viewing.
            </div>
        <?php } else { ?>
            <div class="member-grid">
                <?php foreach ($team_members as $member) { ?>
                <div class="member-card">
                    <?php 
                    // Use helper function to get photo URL (checks UID folder, pending folder, legacy folder)
                    $photo_url = get_verification_photo_url($member, $member->user_id);
                    
                    // Fallback to initials if no photo
                    if (empty($photo_url)) {
                        $photo_url = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="150" height="150"%3E%3Crect fill="%23667eea" width="150" height="150"/%3E%3Ctext x="50%25" y="50%25" font-size="60" fill="white" text-anchor="middle" dy=".3em"%3E' . strtoupper(substr($member->first_name, 0, 1) . substr($member->last_name, 0, 1)) . '%3C/text%3E%3C/svg%3E';
                    }
                    ?>
                    <img src="<?php echo $photo_url; ?>" alt="<?php echo $member->first_name . ' ' . $member->last_name; ?>" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=&quot;http://www.w3.org/2000/svg&quot; width=&quot;150&quot; height=&quot;150&quot;%3E%3Crect fill=&quot;%23667eea&quot; width=&quot;150&quot; height=&quot;150&quot;/%3E%3Ctext x=&quot;50%25&quot; y=&quot;50%25&quot; font-size=&quot;60&quot; fill=&quot;white&quot; text-anchor=&quot;middle&quot; dy=&quot;.3em&quot;%3E<?php echo strtoupper(substr($member->first_name, 0, 1) . substr($member->last_name, 0, 1)); ?>%3C/text%3E%3C/svg%3E';">
                    
                    <div class="member-name"><?php echo $member->first_name . ' ' . $member->last_name; ?></div>
                    <?php if ($member->job_title) { ?>
                        <div class="member-title"><?php echo $member->job_title; ?></div>
                    <?php } ?>
                    
                    <?php
                    $badge_class = 'badge-success';
                    $badge_text = 'DBS Verified';
                    if ($member->dbs_status == 'pending') {
                        $badge_class = 'badge-warning';
                        $badge_text = 'Pending';
                    } elseif ($member->dbs_status != 'verified') {
                        $badge_class = 'badge-danger';
                        $badge_text = 'Not Verified';
                    }
                    ?>
                    <div class="badge <?php echo $badge_class; ?>"><?php echo $badge_text; ?></div>
                    
                    <br>
                    <a href="<?php echo base_url('index.php/public_team/profile/' . $member->uuid); ?>" class="btn btn-primary">View Profile</a>
                </div>
                <?php } ?>
            </div>
        <?php } ?>
    </div>
</body>
</html>
