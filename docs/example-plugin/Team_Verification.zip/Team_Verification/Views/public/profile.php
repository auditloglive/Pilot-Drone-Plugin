<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $user_info->first_name . ' ' . $user_info->last_name; ?> - AuditLog Verified</title>
    <link rel="icon" type="image/png" href="<?php echo base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/auditlog-favicon.png'); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/css/team_verification.css'); ?>">
</head>
<body>
    <div class="public-directory-header">
        <div class="container py-4">
            <div class="text-center mb-3">
                <img src="<?php echo base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/auditlog-logo.png'); ?>" 
                     alt="AuditLog" 
                     style="max-width: 250px; height: auto;">
            </div>
            <a href="<?php echo base_url('public_team'); ?>" class="btn btn-light btn-sm mb-3">
                <i class="fas fa-arrow-left me-1"></i> Back to Directory
            </a>
            <h1 class="text-white mb-0">Team Member Profile</h1>
        </div>
    </div>

    <div class="container py-5">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="card profile-card">
                    <?php 
                    // Always prioritize verification photo over CRM profile image
                    if ($verification->photo_file) {
                        $photo_url = base_url(PLUGIN_URL_PATH . 'Team_Verification/files/photos/' . $verification->photo_file);
                    } else {
                        $photo_url = base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/default-avatar.svg');
                    }
                    ?>
                    <img src="<?php echo $photo_url; ?>" alt="<?php echo $user_info->first_name . ' ' . $user_info->last_name; ?>" class="profile-photo">
                    
                    <div class="card-body text-center">
                        <h3 class="mb-2"><?php echo $user_info->first_name . ' ' . $user_info->last_name; ?></h3>
                        <?php if ($user_info->job_title) { ?>
                            <p class="text-muted mb-3"><?php echo $user_info->job_title; ?></p>
                        <?php } ?>
                        
                        <?php if ($is_authorized) { ?>
                            <div class="authorized-banner">
                                <i class="fas fa-shield-check fa-3x mb-2"></i>
                                <h5>AUTHORIZED</h5>
                                <p class="mb-0 small">DBS Verified Team Member</p>
                            </div>
                        <?php } else { ?>
                            <div class="alert alert-danger mb-3">
                                <i class="fas fa-exclamation-triangle fa-3x mb-2"></i>
                                <h5 class="text-danger">NOT AUTHORISED</h5>
                                <p class="mb-0 small">This team member is not currently authorized</p>
                            </div>
                        <?php } ?>

                        <div class="mt-3">
                            <?php if ($is_authorized) { ?>
                                <button type="button" class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#shareProfileModal">
                                    <i class="fas fa-share-alt me-2"></i>Share Profile
                                </button>
                            <?php } else { ?>
                                <button type="button" class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#reportModal">
                                    <i class="fas fa-flag me-2"></i>Report This Person
                                </button>
                            <?php } ?>
                        </div>
                    </div>
                </div>

                <div class="card mt-3">
                    <div class="card-body text-center">
                        <h6 class="mb-3">Scan to Verify</h6>
                        <?php 
                        $profile_url = base_url('public_team/profile/' . $verification->uuid);
                        $qr_code_url = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($profile_url);
                        ?>
                        <img src="<?php echo $qr_code_url; ?>" alt="QR Code" class="img-fluid" style="max-width: 200px;">
                        <p class="small text-muted mt-2 mb-0">Scan to view this profile</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <?php if ($verification->uid_card_number) { ?>
                <div class="card mb-4 border-primary">
                    <div class="card-body text-center bg-light">
                        <h6 class="text-muted mb-2"><i class="fas fa-id-badge me-2"></i>UID Card Number</h6>
                        <h3 class="mb-0 text-primary"><strong><?php echo $verification->uid_card_number; ?></strong></h3>
                    </div>
                </div>
                <?php } ?>
                
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-certificate me-2"></i>Verification Status</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">DBS Status</label>
                                <?php
                                $status_info = array(
                                    'verified' => array('class' => 'success', 'icon' => 'check-circle', 'text' => 'Verified'),
                                    'pending' => array('class' => 'warning', 'icon' => 'clock', 'text' => 'Pending'),
                                    'expired' => array('class' => 'danger', 'icon' => 'exclamation-triangle', 'text' => 'Expired'),
                                    'rejected' => array('class' => 'secondary', 'icon' => 'times-circle', 'text' => 'Rejected')
                                );
                                $status = $status_info[$verification->dbs_status];
                                ?>
                                <div>
                                    <span class="badge bg-<?php echo $status['class']; ?> fs-6">
                                        <i class="fas fa-<?php echo $status['icon']; ?> me-1"></i>
                                        <?php echo $status['text']; ?>
                                    </span>
                                </div>
                            </div>

                            <?php if ($verification->dbs_certificate_number) { ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">Certificate Number</label>
                                <div><strong><?php echo $verification->dbs_certificate_number; ?></strong></div>
                            </div>
                            <?php } ?>

                            <?php if ($verification->dbs_issue_date) { ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">Issue Date</label>
                                <div><strong><?php echo date('d M Y', strtotime($verification->dbs_issue_date)); ?></strong></div>
                            </div>
                            <?php } ?>

                            <?php if ($verification->dbs_expiry_date) { ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">Expiry Date</label>
                                <div><strong><?php echo date('d M Y', strtotime($verification->dbs_expiry_date)); ?></strong></div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>

                <?php if ($verification->identification_type) { ?>
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0"><i class="fas fa-id-card me-2"></i>Identification Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">Identification Type</label>
                                <div><strong><?php 
                                    $id_types = array(
                                        'passport' => 'Passport',
                                        'drivers_license' => 'Driver\'s License',
                                        'national_id' => 'National ID',
                                        'other' => 'Other'
                                    );
                                    echo isset($id_types[$verification->identification_type]) ? $id_types[$verification->identification_type] : $verification->identification_type;
                                ?></strong></div>
                            </div>

                            <?php if ($verification->identification_number) { ?>
                            <div class="col-md-6 mb-3">
                                <label class="text-muted small">ID Number</label>
                                <div><strong><?php echo substr($verification->identification_number, 0, 4) . str_repeat('*', strlen($verification->identification_number) - 4); ?></strong></div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </div>

    <footer class="public-directory-footer mt-5 py-4">
        <div class="container text-center text-white opacity-75">
            <?php if ($is_authorized) { ?>
                <p class="mb-0">This team member has been verified and authorized to work.</p>
            <?php } else { ?>
                <p class="mb-0">⚠️ This team member is NOT AUTHORISED. If you have encountered this person claiming to work for us, please report them immediately.</p>
            <?php } ?>
        </div>
    </footer>

    <!-- Report Unauthorized Person Modal -->
    <div class="modal fade" id="reportModal" tabindex="-1" aria-labelledby="reportModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="reportModalLabel">
                        <i class="fas fa-flag me-2"></i>Report Unauthorized Person
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        <strong>Important:</strong> If you have encountered someone claiming to be this team member, please provide your details below. A support ticket will be created automatically.
                    </div>

                    <form id="reportForm">
                        <input type="hidden" name="user_id" id="report_user_id" value="<?php echo $user_info->id; ?>">
                        
                        <div class="mb-3">
                            <label class="form-label">Staff Member Being Reported</label>
                            <input type="text" class="form-control" value="<?php echo $user_info->first_name . ' ' . $user_info->last_name; ?>" disabled>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Your Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="reporter_name" id="reporter_name" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Your Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" name="reporter_email" id="reporter_email" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Your Phone Number</label>
                            <input type="tel" class="form-control" name="reporter_phone" id="reporter_phone">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Reason for Report <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="reason" id="reason" rows="4" required placeholder="Please describe when and where you encountered this person, and why you believe they are unauthorized..."></textarea>
                        </div>

                        <div class="alert alert-info small">
                            <i class="fas fa-info-circle me-1"></i>
                            A support ticket will be created in Rise CRM with your report. Our team will investigate and contact you shortly.
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" onclick="submitReport()">
                        <i class="fas fa-paper-plane me-2"></i>Submit Report
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Share Profile Modal -->
    <?php if ($is_authorized) { ?>
    <div class="modal fade" id="shareProfileModal" tabindex="-1" aria-labelledby="shareProfileModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="shareProfileModalLabel">
                        <i class="fas fa-share-alt me-2"></i>Share Profile
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <h6 class="mb-3"><?php echo $user_info->first_name . ' ' . $user_info->last_name; ?></h6>
                    
                    <div class="mb-4">
                        <img src="<?php echo $qr_code_url; ?>" alt="QR Code" class="img-fluid border p-3" style="max-width: 300px;">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small text-muted">Profile URL</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="profileUrl" value="<?php echo $profile_url; ?>" readonly>
                            <button class="btn btn-outline-secondary" type="button" onclick="copyProfileUrl()">
                                <i class="fas fa-copy"></i> Copy
                            </button>
                        </div>
                    </div>

                    <div class="d-grid gap-2">
                        <a href="<?php echo $qr_code_url; ?>&download=1" download="qr-code-<?php echo $user_info->id; ?>.png" class="btn btn-primary">
                            <i class="fas fa-download me-2"></i>Download QR Code
                        </a>
                        <button type="button" class="btn btn-outline-primary" onclick="printQRCode()">
                            <i class="fas fa-print me-2"></i>Print QR Code
                        </button>
                        <button type="button" class="btn btn-success" onclick="shareViaEmail()">
                            <i class="fas fa-envelope me-2"></i>Share via Email
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function submitReport() {
            const form = document.getElementById('reportForm');
            const formData = new FormData(form);

            if (!form.checkValidity()) {
                form.reportValidity();
                return;
            }

            const submitButton = event.target;
            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Submitting...';

            fetch('<?php echo base_url("public_team/submit_report"); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('✓ ' + data.message + '\n\nTicket ID: #' + data.ticket_id + '\n\nOur team will review your report and contact you soon.');
                    const modal = bootstrap.Modal.getInstance(document.getElementById('reportModal'));
                    modal.hide();
                    form.reset();
                } else {
                    alert('✗ ' + data.message);
                }
                submitButton.disabled = false;
                submitButton.innerHTML = '<i class="fas fa-paper-plane me-2"></i>Submit Report';
            })
            .catch(error => {
                alert('An error occurred while submitting your report. Please try again.');
                submitButton.disabled = false;
                submitButton.innerHTML = '<i class="fas fa-paper-plane me-2"></i>Submit Report';
            });
        }
    </script>
    <script>
        function copyProfileUrl() {
            const urlInput = document.getElementById('profileUrl');
            urlInput.select();
            urlInput.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(urlInput.value).then(() => {
                alert('Profile URL copied to clipboard!');
            });
        }

        function printQRCode() {
            const qrCodeUrl = <?php echo json_encode($qr_code_url); ?> + '&size=400x400';
            const userName = <?php echo json_encode($user_info->first_name . ' ' . $user_info->last_name); ?>;
            const jobTitle = <?php echo json_encode($user_info->job_title ? $user_info->job_title : ''); ?>;
            const profileUrl = <?php echo json_encode($profile_url); ?>;
            
            const printWindow = window.open('', '', 'width=600,height=600');
            printWindow.document.write(`
                <html>
                <head>
                    <title>Print QR Code - ${userName}</title>
                    <style>
                        body { 
                            font-family: Arial, sans-serif; 
                            text-align: center; 
                            padding: 20px; 
                        }
                        .qr-container { margin: 20px 0; }
                        img { max-width: 100%; }
                        h2 { margin: 10px 0; }
                        .info { margin: 20px 0; color: #666; }
                    </style>
                </head>
                <body>
                    <h2>${userName}</h2>
                    <p>${jobTitle}</p>
                    <div class="qr-container">
                        <img src="${qrCodeUrl}" alt="QR Code">
                    </div>
                    <div class="info">
                        <p><strong>Scan to view verified profile</strong></p>
                        <p style="font-size: 12px;">${profileUrl}</p>
                    </div>
                </body>
                </html>
            `);
            printWindow.document.close();
            printWindow.onload = function() {
                printWindow.print();
            };
        }

        function shareViaEmail() {
            const userName = <?php echo json_encode($user_info->first_name . ' ' . $user_info->last_name); ?>;
            const profileUrl = <?php echo json_encode($profile_url); ?>;
            const subject = encodeURIComponent('Verified Team Member Profile - ' + userName);
            const body = encodeURIComponent('View the verified profile of ' + userName + ':\n\n' + profileUrl);
            window.location.href = `mailto:?subject=${subject}&body=${body}`;
        }
    </script>
</body>
</html>
