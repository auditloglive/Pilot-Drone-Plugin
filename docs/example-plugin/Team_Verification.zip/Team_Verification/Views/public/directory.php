<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AuditLog - Authorized Team Members Directory</title>
    <link rel="icon" type="image/png" href="<?php echo base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/auditlog-favicon.png'); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/css/team_verification.css'); ?>">
</head>
<body>
    <div class="public-directory-header">
        <div class="container py-5">
            <div class="text-center mb-4">
                <img src="<?php echo base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/auditlog-logo.png'); ?>" 
                     alt="AuditLog" 
                     style="max-width: 300px; height: auto;">
            </div>
            <h1 class="text-white text-center mb-2">Authorized Team Members</h1>
            <p class="text-white text-center opacity-75">Verified and authorized team members with DBS certification</p>
        </div>
    </div>

    <div class="container py-5">
        <!-- Search Box -->
        <div class="row mb-4">
            <div class="col-md-6 offset-md-3">
                <div class="input-group input-group-lg">
                    <span class="input-group-text bg-white">
                        <i class="fas fa-search"></i>
                    </span>
                    <input type="text" id="teamSearch" class="form-control" placeholder="Search by name or job title...">
                </div>
                <p class="text-muted text-center mt-2 mb-0" id="searchResults"></p>
            </div>
        </div>
        <?php if (empty($team_members)) { ?>
            <div class="alert alert-info text-center">
                <i class="fas fa-info-circle me-2"></i>
                No authorized team members are currently available for public viewing.
            </div>
        <?php } else { ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                <?php foreach ($team_members as $member) { 
                    // Always prioritize verification photo over CRM profile image
                    if ($member->photo_file) {
                        $photo_url = base_url(PLUGIN_URL_PATH . 'Team_Verification/files/photos/' . $member->photo_file);
                    } else {
                        $photo_url = base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/images/default-avatar.svg');
                    }
                    
                    $is_verified = $member->dbs_status == 'verified';
                ?>
                <div class="col">
                    <div class="team-member-card">
                        <div class="member-photo-wrapper">
                            <img src="<?php echo $photo_url; ?>" alt="<?php echo $member->first_name . ' ' . $member->last_name; ?>" class="member-photo">
                            <?php if ($is_verified) { ?>
                                <div class="verified-badge">
                                    <i class="fas fa-check-circle"></i>
                                    <span>Authorized</span>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="member-info">
                            <h5 class="member-name"><?php echo $member->first_name . ' ' . $member->last_name; ?></h5>
                            <?php if ($member->job_title) { ?>
                                <p class="member-title text-muted mb-3"><?php echo $member->job_title; ?></p>
                            <?php } ?>
                            
                            <div class="member-status mb-3">
                                <?php
                                $status_info = array(
                                    'verified' => array('class' => 'success', 'icon' => 'check-circle', 'text' => 'DBS Verified'),
                                    'pending' => array('class' => 'warning', 'icon' => 'clock', 'text' => 'Verification Pending'),
                                    'expired' => array('class' => 'danger', 'icon' => 'exclamation-triangle', 'text' => 'DBS Expired'),
                                    'rejected' => array('class' => 'secondary', 'icon' => 'times-circle', 'text' => 'Not Verified')
                                );
                                $status = $status_info[$member->dbs_status];
                                ?>
                                <span class="badge bg-<?php echo $status['class']; ?>">
                                    <i class="fas fa-<?php echo $status['icon']; ?> me-1"></i>
                                    <?php echo $status['text']; ?>
                                </span>
                            </div>

                            <a href="<?php echo base_url('public_team/profile/' . $member->uuid); ?>" class="btn btn-outline-primary btn-sm w-100">
                                <i class="fas fa-id-card me-1"></i> View Full Profile
                            </a>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        <?php } ?>
    </div>

    <footer class="public-directory-footer mt-5 py-4">
        <div class="container text-center text-white opacity-75">
            <p class="mb-0">All team members listed have undergone verification and background checks.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Search functionality
        document.getElementById('teamSearch').addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const memberCards = document.querySelectorAll('.team-member-card');
            let visibleCount = 0;

            memberCards.forEach(function(card) {
                const name = card.querySelector('.member-name').textContent.toLowerCase();
                const title = card.querySelector('.member-title');
                const titleText = title ? title.textContent.toLowerCase() : '';
                
                if (name.includes(searchTerm) || titleText.includes(searchTerm)) {
                    card.closest('.col').style.display = '';
                    visibleCount++;
                } else {
                    card.closest('.col').style.display = 'none';
                }
            });

            // Update search results count
            const resultsEl = document.getElementById('searchResults');
            if (searchTerm) {
                resultsEl.textContent = visibleCount + ' member(s) found';
            } else {
                resultsEl.textContent = '';
            }
        });
    </script>
</body>
</html>
