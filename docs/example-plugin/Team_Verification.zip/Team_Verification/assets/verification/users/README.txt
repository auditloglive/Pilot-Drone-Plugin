VerifyiD By AuditLog - File Storage
====================================

This folder stores all team member verification files in a UID-based structure:

Directory Structure:
-------------------
verification/users/
├── {UID}/              (e.g., TV-001)
│   ├── Profile Image/  (Team member photos)
│   └── Document/       (DBS certificates, ID documents)
└── pending/
    └── {user_id}/      (Files waiting for UID assignment)
        ├── Profile Image/
        └── Document/

Supported Formats:
-----------------
Images: JPG, PNG, GIF, BMP, WEBP, SVG, TIFF, ICO
Documents: PDF

Security:
--------
- Folders created with 0777 permissions for web server access
- .htaccess restricts access to allowed file types only
- Direct URL access allowed for public profile display

Version: 2.2.0
