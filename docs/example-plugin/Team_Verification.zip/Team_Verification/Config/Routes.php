<?php
namespace Config;

$routes = Services::routes();

// Admin routes (require authentication)
$routes->get('team_verification', 'Team_Verification::index', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/instructions', 'Team_Verification::instructions', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/settings', 'Team_Verification::settings', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/backup', 'Team_Verification::backup', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/export_backup', 'Team_Verification::export_backup', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/list_view', 'Team_Verification::list_view', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/live_debug', 'Team_Verification::live_debug', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/embed_code', 'Team_Verification::embed_code', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/public_directory_embed', 'Team_Verification::public_directory_embed', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/get_public_json', 'Team_Verification::get_public_json', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/manage/(:num)', 'Team_Verification::manage/$1', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('team_verification/view_id_card/(:num)', 'Team_Verification::view_id_card/$1', ['namespace' => 'Team_Verification\Controllers']);
$routes->post('team_verification/(:any)', 'Team_Verification::$1', ['namespace' => 'Team_Verification\Controllers']);

// Public routes (no authentication required - uses App_Controller)
$routes->get('public_team', 'Public_Team::index', ['namespace' => 'Team_Verification\Controllers']);
$routes->get('public_team/profile/(:any)', 'Public_Team::profile/$1', ['namespace' => 'Team_Verification\Controllers']);
$routes->post('public_team/(:any)', 'Public_Team::$1', ['namespace' => 'Team_Verification\Controllers']);
