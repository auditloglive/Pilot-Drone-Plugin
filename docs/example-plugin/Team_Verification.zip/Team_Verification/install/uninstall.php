<?php

if (!function_exists('uninstall_team_verification')) {
    function uninstall_team_verification() {
        return true;
    }
}

return uninstall_team_verification();
