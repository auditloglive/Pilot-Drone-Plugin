<?php

if (!function_exists('install_team_verification')) {
    function install_team_verification() {
        $CI = &get_instance();
        $db = $CI->db;
        
        $table_name = $db->prefixTable('team_verification');
        
        if (!$db->tableExists($table_name)) {
            $sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `user_id` int(11) NOT NULL,
                `uuid` varchar(36) NOT NULL,
                `dbs_status` enum('pending','verified','expired','rejected') NOT NULL DEFAULT 'pending',
                `dbs_certificate_number` varchar(100) DEFAULT NULL,
                `dbs_issue_date` date DEFAULT NULL,
                `dbs_expiry_date` date DEFAULT NULL,
                `dbs_document_file` varchar(255) DEFAULT NULL,
                `identification_type` varchar(50) DEFAULT NULL,
                `identification_number` varchar(100) DEFAULT NULL,
                `identification_document_file` varchar(255) DEFAULT NULL,
                `photo_file` varchar(255) DEFAULT NULL,
                `uid_card_number` varchar(50) DEFAULT NULL,
                `public_visibility` tinyint(1) NOT NULL DEFAULT 0,
                `notes` text DEFAULT NULL,
                `created_at` datetime NOT NULL,
                `updated_at` datetime DEFAULT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uuid` (`uuid`),
                UNIQUE KEY `user_id` (`user_id`),
                UNIQUE KEY `uid_card_number` (`uid_card_number`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            
            $db->query($sql);
        }
        
        return true;
    }
}

return install_team_verification();
