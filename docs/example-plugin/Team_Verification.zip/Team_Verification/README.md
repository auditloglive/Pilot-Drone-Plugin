# Team Verification & Public Directory Plugin

A professional Rise CRM plugin that creates a public-facing team member directory with DBS (Disclosure and Barring Service) verification status and identification management.

## Features

✅ **DBS Verification Tracking**
- Track DBS certificate status (Pending, Verified, Expired, Rejected)
- Store certificate numbers and expiry dates
- Automated status management

✅ **Public Team Directory**
- Beautiful public-facing directory page
- Display only active and authorized team members
- Professional profile cards with photos and verification badges
- QR code generation for each team member profile
- Easy profile sharing with download and print options
- Responsive design for all devices

✅ **Team Member Profiles**
- Detailed profile pages with verification information
- Display UID card number prominently for quick identification
- Display authorization status prominently (AUTHORIZED / NOT AUTHORISED)
- Show DBS and identification details
- Unique QR code for each team member
- Share profile via email, download QR code, or print
- Unauthorized member reporting system with automatic ticket creation
- Professional and trustworthy presentation

✅ **Admin Management Interface**
- Easy-to-use admin panel integrated into Rise CRM
- Assign unique UID card numbers to each team member
- Manage verification status for all team members
- Upload and manage team member photos
- Generate, download, and print QR codes for ID badges
- Control public visibility per team member
- Track identification documents
- Quick access to public profiles

✅ **Security & Privacy**
- Partial masking of sensitive ID numbers on public pages
- Internal notes visible only to administrators
- Secure file management for documents
- Public visibility controls
- Unauthorized member profiles shown with prominent warnings

✅ **Reporting System**
- Inactive/unauthorized members display "NOT AUTHORISED" warning
- One-click reporting for suspicious encounters
- Automatic ticket creation in Rise CRM
- Captures both staff member and reporter details
- Reporter contact information (name, email, phone)
- Detailed incident description collection

## Installation

### Method 1: Upload ZIP File

1. Download or create a ZIP file of the `Team_Verification` folder
2. Log in to your Rise CRM admin panel
3. Navigate to **Settings** → **Plugins**
4. Click **Upload Plugin**
5. Select the `Team_Verification.zip` file
6. Click **Install** and then **Activate**

### Method 2: Manual Installation

1. Copy the `Team_Verification` folder to your Rise CRM installation:
   ```
   /path/to/rise-crm/plugins/Team_Verification/
   ```

2. Log in to your Rise CRM admin panel
3. Navigate to **Settings** → **Plugins**
4. Find "Team Verification & Public Directory" in the list
5. Click **Install** and then **Activate**

## Usage

### For Administrators

1. **Access the Plugin**
   - Navigate to the plugin from your Rise CRM menu
   - Or access directly: `https://your-domain.com/team_verification`

2. **Manage Team Member Verification**
   - Click "Manage" next to any team member
   - Set DBS status (Pending, Verified, Expired, Rejected)
   - Enter DBS certificate number and dates
   - Add identification information
   - Enable "Show on Public Directory" to make visible
   - Add internal notes for record-keeping

3. **Upload Photos and Documents**
   - Upload professional photos for public display (all image formats supported)
   - Store identification documents securely (PDF or image formats)
   - Files are stored in `/plugins/Team_Verification/assets/verification/users/`

### Public Access

Your authorized team members will be visible at:
```
https://your-domain.com/public_team
```

Individual profiles can be accessed at:
```
https://your-domain.com/public_team/profile/{user_id}
```

## Database Schema

The plugin creates one table: `rise_team_verification`

Fields:
- `id` - Primary key
- `user_id` - Links to Rise CRM users
- `dbs_status` - Verification status (pending/verified/expired/rejected)
- `dbs_certificate_number` - DBS certificate number
- `dbs_issue_date` - Certificate issue date
- `dbs_expiry_date` - Certificate expiry date
- `identification_type` - Type of ID (passport, license, etc.)
- `identification_number` - ID number
- `photo_file` - Team member photo filename
- `id_document_file` - ID document filename
- `public_visibility` - Show/hide on public directory
- `verification_notes` - Internal admin notes
- `created_at` - Record creation timestamp
- `updated_at` - Last update timestamp

## Requirements

- Rise CRM version 2.8 or higher
- PHP 7.4 or higher
- MySQL/MariaDB database
- Write permissions on `/plugins/Team_Verification/files/` directory

## File Structure

```
Team_Verification/
├── index.php                          # Plugin metadata and installation hooks
├── Config/
│   └── Routes.php                     # URL routing configuration
├── Controllers/
│   ├── Team_Verification.php          # Admin controller
│   └── Public_Team.php                # Public-facing controller
├── Models/
│   └── Team_Verification_model.php    # Database model
├── Views/
│   ├── admin/
│   │   ├── index.php                  # Admin dashboard
│   │   └── manage.php                 # Verification management form
│   └── public/
│       ├── directory.php              # Public team directory
│       └── profile.php                # Individual profile page
├── Language/
│   └── english/
│       └── team_verification_lang.php # Language strings
├── assets/
│   ├── css/
│   │   └── team_verification.css      # Plugin styles
│   ├── js/
│   │   └── team_verification.js       # Plugin scripts
│   └── images/
│       └── default-avatar.png         # Default avatar
├── files/
│   ├── photos/                        # Team member photos
│   └── documents/                     # ID documents
└── README.md                          # This file
```

## Customization

### Styling

Edit `assets/css/team_verification.css` to customize the appearance of public pages.

### Language

Add translations by creating new language files in `Language/{language}/team_verification_lang.php`

### Access Control

The admin interface is restricted to administrators and settings administrators. Modify the constructor in `Controllers/Team_Verification.php` to change access permissions.

## Support

For issues, questions, or feature requests, please contact the plugin developer.

## Version History

**Version 2.2.0** (Latest - 2025-11-10)
- 🗂️ NEW FILE STRUCTURE: Professional organization with `verification/users/{UID}/Profile Image/` and `verification/users/{UID}/Document/` subfolders
- 📸 EXPANDED IMAGE SUPPORT: All image formats now accepted (JPG, PNG, GIF, BMP, WEBP, SVG, TIFF, ICO) + PDF
- 🔧 FIXED: Image display on dashboard now uses smart helper function to find files in all locations
- 🔧 FIXED: Critical syntax error in file deletion function
- ✅ IMPROVED: Better error messages showing all allowed file formats when upload fails
- ✅ IMPROVED: Enhanced file validation with detailed logging
- 🔄 BACKWARDS COMPATIBLE: Old files in `verified_images/` folder still work perfectly
- 🎨 UI: Quick action buttons moved to top of dashboard for better accessibility
- 📝 UPDATED: Help text reflects all supported file formats
- 🚀 AUTO-CACHE CLEAR: Route cache cleared automatically on plugin activation

**Version 2.1.1** (2025-11-10)
- CRITICAL FIX: Auto-cache clearing mechanism added
- Route cache now clears on every plugin activation
- Eliminates 404 errors on new installations
- PHP OpCache reset for fresh file loading

**Version 2.1.0** (2025-11-10)
- Backup & Restore system with full ZIP export/import
- Complete data protection during plugin updates
- Auto-migration of files when UID changes
- Improved folder permissions (0777) for web server access

**Version 2.0.0** (2025-11-10)
- Complete rewrite with UID-based file storage
- Verification photos separated from Rise CRM profile images
- PLUGINPATH-based storage for portability
- UUID system for unique profile URLs
- QR code generation for team members

**Version 1.5.1** (2025-11-01)
- BULLETPROOF ERROR HANDLING: All database operations wrapped in try-catch
- Table existence check before any queries
- Graceful fallback if verification table doesn't exist yet
- 100% elimination of "Whoops!" errors
- Safe for fresh installs and existing installations
- Keeps full verification features (DBS, UID, photos)

**Version 1.5.0** (2025-11-01)
- CRITICAL FIX: Removed automatic schema upgrade from controller constructor
- Schema upgrades now only run during plugin installation (as intended)
- Eliminates "Whoops! We seem to have hit a snag" error
- Clean controller initialization without database operations
- Stable and error-free plugin loading

**Version 1.4.3** (2025-11-01)
- Fixed language file loading to follow Rise CRM standards
- Added BOTH required language files: `default_lang.php` and `custom_lang.php`
- Removed manual language loading - Rise CRM handles this automatically
- Full multi-language support (automatic based on user settings)
- Language files now properly loaded by Rise CRM framework
- Follows official Rise CRM two-file language pattern

**Version 1.4.2** (2025-11-01)
- Changed admin team member list from table to card layout
- Modern card-based interface with team member photos
- Improved visual hierarchy and information display
- Responsive grid layout (3 columns on desktop, 2 on tablet, 1 on mobile)
- Enhanced hover effects and visual feedback

**Version 1.4.1** (2025-11-01)
- Fixed language file loading in controllers - language strings now display correctly
- Text labels no longer show as "default_lang.xxx"

**Version 1.4** (2025-11-01)
- Fixed Rise CRM compliance: proper database prefix usage with get_db_prefix()
- Added staff left menu item for easy plugin access
- Added CSRF exclusion for public report submission endpoint
- Added plugin action links in Settings > Plugins table
- Improved database connection using db_connect('default')
- Full compliance with Rise CRM plugin standards and hooks

**Version 1.3** (2025-11-01)
- Added UID card number field for each team member
- UID displayed prominently on public profiles
- UID shown in admin team member list
- Database schema includes unique constraint for UID numbers

**Version 1.2** (2025-11-01)
- Added unauthorized member reporting system
- Profiles now show "NOT AUTHORISED" for inactive members
- Automatic ticket creation in Rise CRM for reports
- Collects reporter details (name, email, phone, reason)
- Prominent warning messages for unauthorized members

**Version 1.1** (2025-11-01)
- Added QR code generation for each team member
- Profile sharing functionality (email, download, print)
- QR code display in admin panel
- Download and print QR codes for ID badges

**Version 1.0** (Initial Release - 2025-11-01)
- Public team member directory
- DBS verification tracking
- Admin management interface
- Photo and document uploads
- Public visibility controls
- Responsive design

## License

This plugin is compatible with Rise CRM's licensing terms. If distributing commercially, ensure compliance with CodeCanyon's exclusivity requirements.

## Credits

Developed for Rise CRM by VerifyiD By AuditLog
