<?php

defined('PLUGINPATH') or exit('No direct script access allowed');

// Global version constant - Update this in ONE place only
define('TEAM_VERIFICATION_VERSION', '2.2.0');
define('TEAM_VERIFICATION_BUILD_DATE', '2025-11-10');

/*
Plugin Name: VerifyiD By AuditLog
Plugin URL: https://auditlog.co.uk
Description: Team member verification system with DBS tracking, public directory, and ID card generation. Shows authorized team members with photos and credentials on a public-facing portal.
Version: 2.2.0
Build Date: 2025-11-10
Requires at least: 2.8
Author: AuditLog
Author URL: https://auditlog.co.uk
*/

// CACHE BUSTER: Force PHP OpCache to reload all plugin files
if (function_exists('opcache_reset')) {
    @opcache_reset();
}

// ROUTE CACHE CLEARER: Delete Rise CRM's cached routes so new routes are recognized
$route_cache_path = APPPATH . 'cache/routes/';
if (is_dir($route_cache_path)) {
    $files = glob($route_cache_path . '*.php');
    if ($files) {
        foreach ($files as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
    }
}

// Define plugin URL path constant for assets
if (!defined('PLUGIN_URL_PATH')) {
    define('PLUGIN_URL_PATH', 'plugins/');
}

register_installation_hook("Team_Verification", "install_team_verification");
register_uninstallation_hook("Team_Verification", "uninstall_team_verification");

function install_team_verification() {
    // Clear route cache so new routes are recognized immediately
    clear_team_verification_route_cache();
    
    // Create NEW folder structure on plugin installation
    $base_path = __DIR__ . '/assets/verification/users/';
    $pending_path = $base_path . 'pending/';
    
    if (!is_dir($base_path)) {
        mkdir($base_path, 0777, true);
        chmod($base_path, 0777);
    }
    
    if (!is_dir($pending_path)) {
        mkdir($pending_path, 0777, true);
        chmod($pending_path, 0777);
    }
    
    // Create .htaccess for direct photo access
    $htaccess_file = $base_path . '.htaccess';
    if (!file_exists($htaccess_file)) {
        $htaccess_content = "<IfModule mod_rewrite.c>\n    RewriteEngine Off\n</IfModule>\n\n";
        $htaccess_content .= "<FilesMatch \"\\.(jpg|jpeg|png|gif|bmp|webp|svg|tiff|tif|ico|pdf)$\">\n    Order allow,deny\n    Allow from all\n</FilesMatch>";
        file_put_contents($htaccess_file, $htaccess_content);
    }
    
    $db = db_connect('default');
    $db_prefix = get_db_prefix();
    
    $sql = "CREATE TABLE IF NOT EXISTS `" . $db_prefix . "team_verification` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) NOT NULL,
        `uuid` varchar(36) DEFAULT NULL,
        `uid_card_number` varchar(100) DEFAULT NULL,
        `dbs_status` enum('pending','verified','expired','rejected') DEFAULT 'pending',
        `dbs_certificate_number` varchar(255) DEFAULT NULL,
        `dbs_issue_date` date DEFAULT NULL,
        `dbs_expiry_date` date DEFAULT NULL,
        `identification_type` varchar(100) DEFAULT NULL,
        `identification_number` varchar(255) DEFAULT NULL,
        `photo_file` varchar(255) DEFAULT NULL,
        `id_document_file` varchar(255) DEFAULT NULL,
        `public_visibility` tinyint(1) DEFAULT 0,
        `verification_notes` text DEFAULT NULL,
        `created_at` datetime DEFAULT NULL,
        `updated_at` datetime DEFAULT NULL,
        PRIMARY KEY (`id`),
        KEY `user_id` (`user_id`),
        UNIQUE KEY `uuid` (`uuid`),
        UNIQUE KEY `uid_card_number` (`uid_card_number`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
    
    $db->query($sql);
    
    upgrade_team_verification_schema($db);
    
    return true;
}

function upgrade_team_verification_schema($db) {
    $db_prefix = get_db_prefix();
    $table_name = $db_prefix . 'team_verification';
    $fields = $db->getFieldNames($table_name);
    
    if (!in_array('uid_card_number', $fields)) {
        $sql = "ALTER TABLE `" . $table_name . "` 
                ADD COLUMN `uid_card_number` varchar(100) DEFAULT NULL AFTER `user_id`,
                ADD UNIQUE KEY `uid_card_number` (`uid_card_number`)";
        $db->query($sql);
    }
    
    if (!in_array('uuid', $fields)) {
        $sql = "ALTER TABLE `" . $table_name . "` 
                ADD COLUMN `uuid` varchar(36) DEFAULT NULL AFTER `user_id`,
                ADD UNIQUE KEY `uuid` (`uuid`)";
        $db->query($sql);
        
        // Generate UUIDs for existing records
        $existing_records = $db->query("SELECT id FROM `" . $table_name . "`")->getResult();
        foreach ($existing_records as $record) {
            $uuid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                mt_rand(0, 0xffff),
                mt_rand(0, 0x0fff) | 0x4000,
                mt_rand(0, 0x3fff) | 0x8000,
                mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
            );
            $db->query("UPDATE `" . $table_name . "` SET uuid = ? WHERE id = ?", [$uuid, $record->id]);
        }
    }
    
    // Clean up verification data for inactive users older than 10 years
    cleanup_old_inactive_verification_data($db);
}

function cleanup_old_inactive_verification_data($db) {
    $db_prefix = get_db_prefix();
    $table_name = $db_prefix . 'team_verification';
    $users_table = $db_prefix . 'users';
    
    // Delete verification data for users who have been inactive for more than 10 years
    $ten_years_ago = date('Y-m-d H:i:s', strtotime('-10 years'));
    
    $sql = "DELETE tv FROM `" . $table_name . "` tv
            INNER JOIN `" . $users_table . "` u ON tv.user_id = u.id
            WHERE (u.status = 'inactive' OR u.deleted = 1)
            AND tv.updated_at < ?
            AND tv.updated_at IS NOT NULL";
    
    try {
        $db->query($sql, [$ten_years_ago]);
    } catch (\Exception $e) {
        // Ignore errors during cleanup
    }
}

function uninstall_team_verification() {
    // DO NOT delete the table - preserve all verification data
    // Data will be retained even when plugin is inactive/deleted
    // Only inactive account data older than 10 years will be cleaned up automatically
    return true;
}

function clear_team_verification_route_cache() {
    // Delete Rise CRM's cached route files to force route reload
    $route_cache_path = APPPATH . 'cache/routes/';
    if (is_dir($route_cache_path)) {
        $files = glob($route_cache_path . '*.php');
        if ($files) {
            foreach ($files as $file) {
                if (is_file($file)) {
                    @unlink($file);
                }
            }
        }
    }
    
    // Also try to clear general cache if available
    if (function_exists('delete_cache')) {
        delete_cache();
    }
}

app_hooks()->add_filter('app_filter_staff_left_menu', function ($sidebar_menu) {
    $sidebar_menu["team_verification"] = array(
        "name" => "team_verification",
        "url" => "team_verification",
        "class" => "user-check",
        "position" => 20
    );

    return $sidebar_menu;
});

app_hooks()->add_filter('app_filter_action_links_of_Team_Verification', function ($action_links_array) {
    $action_links_array = array(
        anchor(get_uri("team_verification"), app_lang("manage")),
        anchor(get_uri("public_team"), app_lang("view_public_directory"), array("target" => "_blank"))
    );

    return $action_links_array;
});

// Register public routes via hook (REQUIRED - public requests never load Config/Routes.php)
app_hooks()->add_filter('app_filter_router', function ($routes) {
    // Public routes - must use full namespace path
    $routes->get('public_team', '\Team_Verification\Controllers\Public_Team::index');
    $routes->get('public_team/profile/(:any)', '\Team_Verification\Controllers\Public_Team::profile/$1');
    $routes->post('public_team/submit_report', '\Team_Verification\Controllers\Public_Team::submit_report');
    
    // Debug routes (admin only)
    $routes->get('team_verification/debug', '\Team_Verification\Controllers\Debug::index');
    $routes->get('team_verification/live_debug', '\Team_Verification\Controllers\Team_Verification::live_debug');
    $routes->post('team_verification/clear_debug_logs', '\Team_Verification\Controllers\Team_Verification::clear_debug_logs');
    
    return $routes;
});


/**
 * Get the storage directory for verification files (inside plugin assets)
 * Uses UID-based folders when available, otherwise user_id pending folder
 */
function get_verification_storage_path($user_id, $uid_card_number = null, $subfolder = '') {
    // Base path: Team_Verification/assets/verification/users/
    $base_path = PLUGINPATH . 'Team_Verification/assets/verification/users/';
    
    if ($uid_card_number) {
        // UID assigned: use UID-based folder
        $target_path = $base_path . clean_filename($uid_card_number) . '/';
    } else {
        // No UID yet: use pending folder with user_id
        $target_path = $base_path . 'pending/' . $user_id . '/';
    }
    
    // Add subfolder if specified (Profile Image or Document - with capital letters)
    if ($subfolder === 'profile_image') {
        $target_path .= 'Profile Image/';
    } else if ($subfolder === 'id_document') {
        $target_path .= 'Document/';
    }
    
    // Create directory if it doesn't exist
    if (!is_dir($target_path)) {
        if (!mkdir($target_path, 0777, true)) {
            log_message('error', 'Team Verification: Failed to create directory: ' . $target_path);
        } else {
            chmod($target_path, 0777); // Ensure writable
            log_message('info', 'Team Verification: Created directory: ' . $target_path);
        }
    }
    
    return $target_path;
}

/**
 * Get the URL for a verification photo
 * Checks multiple locations: UID folder, pending folder, legacy folder
 * Returns empty string if file doesn't exist (triggers initials fallback)
 */
function get_verification_photo_url($verification, $user_id = null) {
    if (empty($verification->photo_file)) {
        return '';
    }
    
    $filename = $verification->photo_file;
    $base_path = __DIR__ . '/assets/verification/users/';
    $base_url_assets = base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/verification/users/');
    
    // Try new structure: UID/Profile Image/
    if (!empty($verification->uid_card_number)) {
        $uid_path = $base_path . clean_filename($verification->uid_card_number) . '/Profile Image/' . $filename;
        if (file_exists($uid_path)) {
            return $base_url_assets . clean_filename($verification->uid_card_number) . '/Profile%20Image/' . $filename;
        }
    }
    
    // Try pending folder: pending/user_id/Profile Image/
    if ($user_id || !empty($verification->user_id)) {
        $uid_to_check = $user_id ?: $verification->user_id;
        $pending_path = $base_path . 'pending/' . $uid_to_check . '/Profile Image/' . $filename;
        if (file_exists($pending_path)) {
            return $base_url_assets . 'pending/' . $uid_to_check . '/Profile%20Image/' . $filename;
        }
    }
    
    // Backwards compatibility: check old verified_images structure
    $old_base = __DIR__ . '/assets/verified_images/';
    $old_url_base = base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/verified_images/');
    
    if (!empty($verification->uid_card_number)) {
        // Try old subfolder structure
        $old_path1 = $old_base . clean_filename($verification->uid_card_number) . '/profile_image/' . $filename;
        if (file_exists($old_path1)) {
            return $old_url_base . clean_filename($verification->uid_card_number) . '/profile_image/' . $filename;
        }
        // Try old flat structure
        $old_path2 = $old_base . clean_filename($verification->uid_card_number) . '/' . $filename;
        if (file_exists($old_path2)) {
            return $old_url_base . clean_filename($verification->uid_card_number) . '/' . $filename;
        }
    }
    
    // File not found anywhere - return empty string to trigger initials fallback
    return '';
}

/**
 * Get the URL for a verification document
 * Checks multiple locations: UID folder, pending folder, legacy folder
 * Returns empty string if file doesn't exist
 */
function get_verification_document_url($verification, $user_id = null) {
    if (empty($verification->id_document_file)) {
        return '';
    }
    
    $filename = $verification->id_document_file;
    $base_path = __DIR__ . '/assets/verification/users/';
    $base_url_assets = base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/verification/users/');
    
    // Try new structure: UID/Document/
    if (!empty($verification->uid_card_number)) {
        $uid_path = $base_path . clean_filename($verification->uid_card_number) . '/Document/' . $filename;
        if (file_exists($uid_path)) {
            return $base_url_assets . clean_filename($verification->uid_card_number) . '/Document/' . $filename;
        }
    }
    
    // Try pending folder: pending/user_id/Document/
    if ($user_id || !empty($verification->user_id)) {
        $uid_to_check = $user_id ?: $verification->user_id;
        $pending_path = $base_path . 'pending/' . $uid_to_check . '/Document/' . $filename;
        if (file_exists($pending_path)) {
            return $base_url_assets . 'pending/' . $uid_to_check . '/Document/' . $filename;
        }
    }
    
    // Backwards compatibility: check old verified_images structure
    $old_base = __DIR__ . '/assets/verified_images/';
    $old_url_base = base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/verified_images/');
    
    if (!empty($verification->uid_card_number)) {
        // Try old subfolder structure
        $old_path1 = $old_base . clean_filename($verification->uid_card_number) . '/id_document/' . $filename;
        if (file_exists($old_path1)) {
            return $old_url_base . clean_filename($verification->uid_card_number) . '/id_document/' . $filename;
        }
        // Try old flat structure
        $old_path2 = $old_base . clean_filename($verification->uid_card_number) . '/' . $filename;
        if (file_exists($old_path2)) {
            return $old_url_base . clean_filename($verification->uid_card_number) . '/' . $filename;
        }
    }
    
    // File not found anywhere - return empty string
    return '';
}

/**
 * Clean filename for safe use in paths
 */
function clean_filename($filename) {
    return preg_replace('/[^a-zA-Z0-9_-]/', '_', $filename);
}

