<?php

namespace Team_Verification\Models;

use App\Models\Crud_model;

class Team_Verification_model extends Crud_model {

    protected $table = null;

    function __construct() {
        $this->table = 'team_verification';
        parent::__construct($this->table);
    }

    function get_public_team_members($options = array()) {
        $team_verification_table = $this->db->prefixTable('team_verification');
        $users_table = $this->db->prefixTable('users');

        $where = "";
        
        if (get_array_value($options, "public_visibility")) {
            $where .= " AND tv.public_visibility = 1";
        }
        
        if (get_array_value($options, "status")) {
            $status = $this->db->escapeString(get_array_value($options, "status"));
            $where .= " AND u.status = '$status'";
        }

        $sql = "SELECT tv.*, u.first_name, u.last_name, u.job_title, u.email, u.image as user_image, u.status as user_status
                FROM $team_verification_table AS tv
                LEFT JOIN $users_table AS u ON u.id = tv.user_id
                WHERE u.deleted = 0 AND u.user_type = 'staff' $where
                ORDER BY u.first_name ASC";

        return $this->db->query($sql)->getResult();
    }
}
