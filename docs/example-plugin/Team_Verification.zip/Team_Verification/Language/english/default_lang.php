<?php

$lang["team_verification"] = "Team Verification";
$lang["tv_team_verification_management"] = "Team Verification Management";
$lang["tv_backup_restore"] = "Backup & Restore";
$lang["view_public_directory"] = "View Public Directory";
$lang["tv_team_member"] = "Team Member";
$lang["tv_job_title"] = "Job Title";
$lang["tv_dbs_status"] = "DBS Status";
$lang["tv_public_visibility"] = "Public Visibility";
$lang["tv_last_updated"] = "Last Updated";
$lang["tv_manage"] = "Manage";
$lang["tv_manage_verification"] = "Manage Verification";

$lang["tv_status_pending"] = "Pending";
$lang["tv_status_verified"] = "Verified";
$lang["tv_status_expired"] = "Expired";
$lang["tv_status_rejected"] = "Rejected";

$lang["tv_card_information"] = "Card Information";
$lang["tv_uid_card_number"] = "UID Card Number";
$lang["tv_uid_card_number_help"] = "Unique identification card number for this team member";
$lang["tv_uid_already_exists"] = "This UID card number is already assigned to another team member";
$lang["tv_generate_uid"] = "Generate";
$lang["tv_uid_generated_success"] = "UID generated successfully";

$lang["tv_dbs_information"] = "DBS Information";
$lang["tv_dbs_certificate_number"] = "DBS Certificate Number";
$lang["tv_dbs_issue_date"] = "Issue Date";
$lang["tv_dbs_expiry_date"] = "Expiry Date";

$lang["tv_identification_information"] = "Identification Information";
$lang["tv_identification_type"] = "Identification Type";
$lang["tv_identification_number"] = "Identification Number";
$lang["tv_passport"] = "Passport";
$lang["tv_drivers_license"] = "Driver's License";
$lang["tv_national_id"] = "National ID";
$lang["tv_other"] = "Other";

$lang["tv_show_on_public_directory"] = "Show on Public Directory";
$lang["tv_public_visibility_help"] = "When enabled, this team member will appear on the public-facing team directory";
$lang["tv_verification_notes"] = "Verification Notes (Internal Only)";

$lang["tv_photo_upload"] = "Upload Photo";
$lang["tv_id_document_upload"] = "Upload ID Document";
$lang["tv_current_photo"] = "Current Photo";
$lang["tv_current_document"] = "Current Document";
$lang["tv_photo_upload_help"] = "Upload a professional photo of the team member (All image formats: JPG, PNG, GIF, BMP, WEBP, SVG, TIFF, max 5MB)";
$lang["tv_id_document_upload_help"] = "Upload identification document (PDF or any image format, max 10MB)";

$lang["tv_qr_code"] = "QR Code";
$lang["tv_download_qr"] = "Download QR Code";
$lang["tv_print_qr"] = "Print QR Code";
$lang["tv_view_public_profile"] = "View Public Profile";
$lang["tv_qr_code_info_title"] = "How to Use QR Codes";
$lang["tv_qr_code_info_text"] = "Each team member has a unique QR code that links directly to their verified profile:";
$lang["tv_qr_code_use_1"] = "Print QR codes on ID badges or staff cards";
$lang["tv_qr_code_use_2"] = "Display at reception or entry points for quick verification";
$lang["tv_qr_code_use_3"] = "Share via email or on company website";

$lang["tv_report_missing_fields"] = "Please fill in all required fields";
$lang["tv_report_invalid_user"] = "Invalid user ID";
$lang["tv_report_submitted_success"] = "Report submitted successfully! A support ticket has been created.";
$lang["tv_report_submission_failed"] = "Failed to submit report. Please try again or contact support directly.";

return $lang;
