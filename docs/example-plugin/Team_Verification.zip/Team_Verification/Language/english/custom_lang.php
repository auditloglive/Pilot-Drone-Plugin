<?php
// Custom language overrides
// Edit this file to customize language strings

// Leave empty if no customizations needed
return [];
