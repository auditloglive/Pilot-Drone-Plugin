<?php

namespace Team_Verification\Controllers;

use App\Controllers\Security_Controller;

class Team_Verification extends Security_Controller {

    public function __construct() {
        parent::__construct();
        $this->access_only_admin_or_settings_admin();
    }

    public function index() {
        // Show dashboard overview
        try {
            $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
            
            $sql = "SELECT 
                        u.id, u.first_name, u.last_name, u.status as user_status,
                        tv.dbs_status, tv.public_visibility
                    FROM " . get_db_prefix() . "users u
                    INNER JOIN " . get_db_prefix() . "team_verification tv ON u.id = tv.user_id
                    WHERE u.deleted = 0 AND u.user_type = 'staff'";
            
            $db = db_connect('default');
            $query = $db->query($sql);
            $view_data['team_members'] = $query->getResult();
            
            return $this->template->rander("Team_Verification\Views\admin\dashboard", $view_data);
        } catch (\Exception $e) {
            $view_data['team_members'] = array();
            return $this->template->rander("Team_Verification\Views\admin\dashboard", $view_data);
        }
    }
    
    public function instructions() {
        // Admin-only instructions page
        $view_data = array();
        return $this->template->rander("Team_Verification\Views\admin\instructions", $view_data);
    }
    
    public function backup() {
        // Backup & Restore page
        $view_data = array();
        return $this->template->rander("Team_Verification\Views\admin\backup", $view_data);
    }
    
    public function export_backup() {
        $this->_safe_log("=== EXPORT BACKUP CALLED ===");
        
        // Create backup ZIP file
        $backup_name = 'team_verification_backup_' . date('Y-m-d_His') . '.zip';
        $backup_path = get_setting("temp_file_path") . $backup_name;
        
        $this->_safe_log("Creating backup file: " . $backup_name);
        $this->_safe_log("Backup path: " . $backup_path);
        
        $zip = new \ZipArchive();
        if ($zip->open($backup_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== TRUE) {
            $this->_safe_log("ERROR: Could not create backup file");
            die("Could not create backup file");
        }
        
        // Add all files from NEW verification/users folder
        $base_path = PLUGINPATH . 'Team_Verification/assets/verification/users/';
        if (is_dir($base_path)) {
            $files = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($base_path, \RecursiveDirectoryIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST
            );
            
            foreach ($files as $file) {
                $file_path = $file->getRealPath();
                $relative_path = 'files/' . substr($file_path, strlen($base_path));
                
                if ($file->isDir()) {
                    $zip->addEmptyDir($relative_path);
                } else {
                    $zip->addFile($file_path, $relative_path);
                }
            }
        }
        
        // BACKWARDS COMPATIBILITY: Also backup OLD verified_images folder if it exists
        $old_base_path = PLUGINPATH . 'Team_Verification/assets/verified_images/';
        if (is_dir($old_base_path)) {
            $old_files = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($old_base_path, \RecursiveDirectoryIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST
            );
            
            foreach ($old_files as $file) {
                $file_path = $file->getRealPath();
                $relative_path = 'files_legacy/' . substr($file_path, strlen($old_base_path));
                
                if ($file->isDir()) {
                    $zip->addEmptyDir($relative_path);
                } else {
                    $zip->addFile($file_path, $relative_path);
                }
            }
        }
        
        // Export database records to JSON
        $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
        $db = db_connect('default');
        $db_prefix = get_db_prefix();
        $query = $db->query("SELECT * FROM " . $db_prefix . "team_verification");
        $records = $query->getResult();
        
        $db_export = array(
            'export_date' => date('Y-m-d H:i:s'),
            'version' => TEAM_VERIFICATION_VERSION,
            'records' => $records
        );
        
        $zip->addFromString('database.json', json_encode($db_export, JSON_PRETTY_PRINT));
        
        // Add README
        $readme = "Team Verification Backup\n";
        $readme .= "========================\n\n";
        $readme .= "Created: " . date('Y-m-d H:i:s') . "\n";
        $readme .= "Records: " . count($records) . "\n\n";
        $readme .= "To restore:\n";
        $readme .= "1. Go to Team Verification → Backup & Restore\n";
        $readme .= "2. Click 'Import Backup'\n";
        $readme .= "3. Select this ZIP file\n";
        $readme .= "4. Confirm the import\n";
        
        $zip->addFromString('README.txt', $readme);
        $zip->close();
        
        // Download the file
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $backup_name . '"');
        header('Content-Length: ' . filesize($backup_path));
        readfile($backup_path);
        
        // Delete temp file
        unlink($backup_path);
        exit;
    }
    
    public function import_backup() {
        if (!$this->request->getPost('confirm_import')) {
            echo json_encode(array("success" => false, "message" => "Import not confirmed"));
            return;
        }
        
        $backup_file = $_FILES['backup_file'] ?? null;
        if (!$backup_file || $backup_file['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(array("success" => false, "message" => "No file uploaded or upload error"));
            return;
        }
        
        $temp_path = get_setting("temp_file_path");
        $zip_path = $temp_path . 'restore_' . time() . '.zip';
        move_uploaded_file($backup_file['tmp_name'], $zip_path);
        
        $zip = new \ZipArchive();
        if ($zip->open($zip_path) !== TRUE) {
            unlink($zip_path);
            echo json_encode(array("success" => false, "message" => "Invalid ZIP file"));
            return;
        }
        
        $extract_path = $temp_path . 'restore_' . time() . '/';
        $zip->extractTo($extract_path);
        $zip->close();
        
        // Restore files to NEW location
        $files_source = $extract_path . 'files/';
        $files_dest = PLUGINPATH . 'Team_Verification/assets/verification/users/';
        
        if (is_dir($files_source)) {
            // Create destination directory if it doesn't exist
            if (!is_dir($files_dest)) {
                mkdir($files_dest, 0777, true);
                chmod($files_dest, 0777);
            }
            $this->_copy_directory($files_source, $files_dest);
        }
        
        // BACKWARDS COMPATIBILITY: Restore legacy files if they exist in backup
        $legacy_source = $extract_path . 'files_legacy/';
        $legacy_dest = PLUGINPATH . 'Team_Verification/assets/verified_images/';
        
        if (is_dir($legacy_source)) {
            if (!is_dir($legacy_dest)) {
                mkdir($legacy_dest, 0777, true);
                chmod($legacy_dest, 0777);
            }
            $this->_copy_directory($legacy_source, $legacy_dest);
        }
        
        // Restore database
        $db_file = $extract_path . 'database.json';
        if (file_exists($db_file)) {
            $db_data = json_decode(file_get_contents($db_file), true);
            
            if (isset($db_data['records'])) {
                $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
                
                foreach ($db_data['records'] as $record) {
                    $record_array = (array)$record;
                    $existing = $Team_Verification_model->get_one_where(array("user_id" => $record_array['user_id']));
                    
                    if (isset($existing->id) && $existing->id) {
                        // Update existing
                        $Team_Verification_model->ci_save($record_array, $existing->id);
                    } else {
                        // Insert new
                        $Team_Verification_model->ci_save($record_array);
                    }
                }
            }
        }
        
        // Cleanup
        $this->_delete_directory($extract_path);
        unlink($zip_path);
        
        app_redirect('team_verification/backup?restore=success');
    }
    
    private function _copy_directory($src, $dst) {
        if (!is_dir($dst)) {
            mkdir($dst, 0777, true);
        }
        
        $dir = opendir($src);
        while (($file = readdir($dir)) !== false) {
            if ($file != '.' && $file != '..') {
                if (is_dir($src . '/' . $file)) {
                    $this->_copy_directory($src . '/' . $file, $dst . '/' . $file);
                } else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }
    
    private function _delete_directory($dir) {
        if (!is_dir($dir)) {
            return;
        }
        
        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            is_dir($path) ? $this->_delete_directory($path) : unlink($path);
        }
        rmdir($dir);
    }
    
    /**
     * Handle file upload via AJAX - save directly to plugin pending folder
     */
    public function upload_file() {
        $this->_safe_log("=== UPLOAD FILE CALLED ===");
        $this->_safe_log("FILES: " . json_encode($_FILES));
        
        try {
            // Check if file was uploaded
            if (empty($_FILES) || !isset($_FILES['file'])) {
                $this->_safe_log("ERROR: No file in request");
                echo json_encode(array("success" => false, "message" => "No file uploaded"));
                return;
            }
            
            $file = $_FILES['file'];
            
            // Validate upload
            if ($file['error'] !== UPLOAD_ERR_OK) {
                $this->_safe_log("ERROR: Upload error code " . $file['error']);
                echo json_encode(array("success" => false, "message" => "Upload error: " . $file['error']));
                return;
            }
            
            // Validate file type
            $allowed_types = array('image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'application/pdf');
            if (!in_array($file['type'], $allowed_types)) {
                $this->_safe_log("ERROR: Invalid file type: " . $file['type']);
                echo json_encode(array("success" => false, "message" => "Invalid file type. Only images and PDFs allowed."));
                return;
            }
            
            // Save directly to plugin's pending folder
            $pending_path = PLUGINPATH . 'Team_Verification/assets/verification/users/pending/';
            
            // Ensure pending folder exists
            if (!is_dir($pending_path)) {
                @mkdir($pending_path, 0777, true);
            }
            
            if (!is_dir($pending_path) || !is_writable($pending_path)) {
                $this->_safe_log("ERROR: Pending folder not writable: " . $pending_path);
                echo json_encode(array("success" => false, "message" => "Upload folder not accessible"));
                return;
            }
            
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $new_filename = uniqid() . '_' . time() . '.' . $extension;
            $target_path = $pending_path . $new_filename;
            
            $this->_safe_log("Saving directly to plugin folder: " . $target_path);
            
            // Move uploaded file to plugin pending folder
            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                $this->_safe_log("SUCCESS: File saved in plugin as " . $new_filename);
                $this->_safe_log("File location: " . $target_path);
                echo json_encode(array(
                    "success" => true,
                    "file_name" => $new_filename,
                    "message" => "File uploaded successfully"
                ));
            } else {
                $this->_safe_log("ERROR: Failed to move uploaded file to " . $target_path);
                echo json_encode(array("success" => false, "message" => "Failed to save file to plugin folder"));
            }
            
            $this->_safe_log("=== UPLOAD COMPLETE ===\n");
            
        } catch (\Exception $e) {
            $this->_safe_log("EXCEPTION: " . $e->getMessage());
            echo json_encode(array("success" => false, "message" => $e->getMessage()));
        }
    }
    
    private function _safe_log($message) {
        // Safe logging that won't crash the system
        try {
            $log_file = PLUGINPATH . 'Team_Verification/assets/verification/debug.log';
            $timestamp = date('Y-m-d H:i:s');
            $log_entry = "[{$timestamp}] {$message}\n";
            @file_put_contents($log_file, $log_entry, FILE_APPEND);
        } catch (\Exception $e) {
            // Silently fail if logging doesn't work
        }
    }
    
    private function _debug_log($message) {
        // Alias for compatibility
        $this->_safe_log($message);
    }
    
    public function settings() {
        $view_data = array();
        return $this->template->rander("Team_Verification\Views\admin\settings", $view_data);
    }
    
    public function live_debug() {
        $view_data = array();
        return $this->template->rander("Team_Verification\Views\admin\live_debug", $view_data);
    }
    
    public function clear_debug_logs() {
        $debug_file = PLUGINPATH . 'Team_Verification/assets/verification/debug.log';
        if (file_exists($debug_file)) {
            unlink($debug_file);
        }
        echo json_encode(array("success" => true, "message" => "Debug logs cleared"));
    }
    
    public function check_filesystem() {
        $report = "FILE SYSTEM CHECK REPORT\n";
        $report .= str_repeat("=", 60) . "\n\n";
        
        $paths = array(
            'Temp Folder' => get_setting("temp_file_path"),
            'Base Storage' => PLUGINPATH . 'Team_Verification/assets/verification/users/',
            'Pending Folder' => PLUGINPATH . 'Team_Verification/assets/verification/users/pending/'
        );
        
        foreach ($paths as $name => $path) {
            $report .= $name . ":\n";
            $report .= "  Path: " . $path . "\n";
            $report .= "  Exists: " . (is_dir($path) ? 'YES' : 'NO') . "\n";
            $report .= "  Writable: " . (is_writable($path) ? 'YES' : 'NO') . "\n";
            $report .= "  Permissions: " . (is_dir($path) ? substr(sprintf('%o', fileperms($path)), -4) : 'N/A') . "\n";
            $report .= "\n";
        }
        
        echo json_encode(array("success" => true, "report" => $report));
    }
    
    public function check_database() {
        $db = db_connect('default');
        $db_prefix = get_db_prefix();
        $table_name = $db_prefix . 'team_verification';
        
        $report = "DATABASE CHECK REPORT\n";
        $report .= str_repeat("=", 60) . "\n\n";
        
        $report .= "Table Name: " . $table_name . "\n";
        $report .= "Table Exists: " . ($db->tableExists($table_name) ? 'YES' : 'NO') . "\n\n";
        
        if ($db->tableExists($table_name)) {
            $fields = $db->getFieldNames($table_name);
            $report .= "Columns (" . count($fields) . "):\n";
            foreach ($fields as $field) {
                $report .= "  - " . $field . "\n";
            }
            
            $count = $db->query("SELECT COUNT(*) as cnt FROM " . $table_name)->getRow()->cnt;
            $report .= "\nTotal Records: " . $count . "\n";
        } else {
            $report .= "ERROR: Table does not exist!\n";
        }
        
        echo json_encode(array("success" => true, "report" => $report));
    }
    
    public function clear_route_cache() {
        clear_team_verification_route_cache();
        echo json_encode(array("success" => true, "message" => "Route cache cleared"));
    }
    
    public function debug() {
        $debug_info = array();
        
        // Check base plugin path
        $base_path = PLUGINPATH . 'Team_Verification/assets/verified_images/';
        $debug_info[] = array(
            'Path' => $base_path,
            'Exists' => is_dir($base_path) ? 'YES' : 'NO',
            'Writable' => is_writable($base_path) ? 'YES' : 'NO',
            'Permissions' => is_dir($base_path) ? substr(sprintf('%o', fileperms($base_path)), -4) : 'N/A'
        );
        
        // Check pending folder
        $pending_path = $base_path . 'pending/';
        $debug_info[] = array(
            'Path' => $pending_path,
            'Exists' => is_dir($pending_path) ? 'YES' : 'NO',
            'Writable' => is_writable($pending_path) ? 'YES' : 'NO',
            'Permissions' => is_dir($pending_path) ? substr(sprintf('%o', fileperms($pending_path)), -4) : 'N/A'
        );
        
        // Check temp file path
        $temp_path = get_setting("temp_file_path");
        $debug_info[] = array(
            'Path' => $temp_path . ' (temp_file_path setting)',
            'Exists' => is_dir($temp_path) ? 'YES' : 'NO',
            'Writable' => is_writable($temp_path) ? 'YES' : 'NO',
            'Permissions' => is_dir($temp_path) ? substr(sprintf('%o', fileperms($temp_path)), -4) : 'N/A'
        );
        
        // Output as HTML
        echo '<!DOCTYPE html><html><head><title>Team Verification Debug</title>';
        echo '<style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #333; }
            table { border-collapse: collapse; width: 100%; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background-color: #4CAF50; color: white; }
            .yes { color: green; font-weight: bold; }
            .no { color: red; font-weight: bold; }
            .info { background-color: #f0f0f0; padding: 15px; margin: 20px 0; border-radius: 5px; }
        </style></head><body>';
        
        echo '<h1>Team Verification - Storage Debug Info</h1>';
        
        echo '<div class="info">';
        echo '<strong>Instructions:</strong><br>';
        echo '1. All paths should show <span class="yes">YES</span> for Exists and Writable<br>';
        echo '2. Permissions should be 0755 or 0777<br>';
        echo '3. If anything shows <span class="no">RED</span>, that\'s the problem!';
        echo '</div>';
        
        echo '<table>';
        echo '<tr><th>Path</th><th>Exists</th><th>Writable</th><th>Permissions</th></tr>';
        
        foreach ($debug_info as $info) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($info['Path']) . '</td>';
            echo '<td class="' . strtolower($info['Exists']) . '">' . $info['Exists'] . '</td>';
            echo '<td class="' . strtolower($info['Writable']) . '">' . $info['Writable'] . '</td>';
            echo '<td>' . $info['Permissions'] . '</td>';
            echo '</tr>';
        }
        
        echo '</table>';
        
        echo '<div class="info">';
        echo '<strong>Next Step:</strong><br>';
        echo '1. Take a screenshot of this page<br>';
        echo '2. Try uploading a photo in the Team Verification page<br>';
        echo '3. Share the error message you see';
        echo '</div>';
        
        echo '</body></html>';
    }
    
    public function list_view() {
        try {
            // Load custom CSS for admin views
            $view_data['custom_css'] = '<link rel="stylesheet" href="' . base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/css/team_verification.css') . '?v=' . time() . '">';
            
            $view_data['users'] = $this->Users_model->get_all_where(array("deleted" => 0, "user_type" => "staff"))->getResult();
            
            $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
            $view_data['verification_data'] = array();
            
            // Check if table exists before querying
            $db = db_connect('default');
            $db_prefix = get_db_prefix();
            if ($db->tableExists($db_prefix . 'team_verification')) {
                foreach ($view_data['users'] as $user) {
                    $verification = $Team_Verification_model->get_one_where(array("user_id" => $user->id));
                    if ($verification && isset($verification->id) && $verification->id) {
                        $view_data['verification_data'][$user->id] = $verification;
                    }
                }
            }
            
            return $this->template->rander("Team_Verification\Views\admin\index", $view_data);
        } catch (\Exception $e) {
            // Fallback to showing users only
            $view_data['custom_css'] = '<link rel="stylesheet" href="' . base_url(PLUGIN_URL_PATH . 'Team_Verification/assets/css/team_verification.css') . '?v=' . time() . '">';
            $view_data['users'] = $this->Users_model->get_all_where(array("deleted" => 0, "user_type" => "staff"))->getResult();
            $view_data['verification_data'] = array();
            return $this->template->rander("Team_Verification\Views\admin\index", $view_data);
        }
    }

    public function manage($user_id = 0) {
        try {
            if (!$user_id) {
                show_404();
            }

            $user_info = $this->Users_model->get_one($user_id);
            if (!$user_info->id || $user_info->deleted || $user_info->user_type !== "staff") {
                show_404();
            }

            $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
            $verification = $Team_Verification_model->get_one_where(array("user_id" => $user_id));
            
            // Create default verification object if none exists
            if (!isset($verification->id) || !$verification->id) {
                $verification = (object) array(
                    'id' => 0,
                    'user_id' => $user_id,
                    'uid_card_number' => '',
                    'dbs_status' => 'pending',
                    'dbs_certificate_number' => '',
                    'dbs_issue_date' => '',
                    'dbs_expiry_date' => '',
                    'identification_type' => '',
                    'identification_number' => '',
                    'public_visibility' => 0,
                    'verification_notes' => '',
                    'photo_file' => '',
                    'id_document_file' => '',
                    'uuid' => '',
                    'created_at' => '',
                    'updated_at' => ''
                );
            }
            
            $view_data['user_info'] = $user_info;
            $view_data['verification'] = $verification;
            $view_data['user_id'] = $user_id;
            
            return $this->template->rander("Team_Verification\Views\admin\manage", $view_data);
        } catch (\Exception $e) {
            show_404();
        }
    }

    public function save() {
        try {
            $this->_safe_log("=== SAVE STARTED ===");
            $this->_safe_log("POST: " . json_encode($this->request->getPost()));
            
            $user_id = $this->request->getPost('user_id');
            
            if (!$user_id) {
                $this->_safe_log("ERROR: No user_id");
                echo json_encode(array("success" => false, 'message' => 'Invalid request'));
                return;
            }

        $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
        $verification = $Team_Verification_model->get_one_where(array("user_id" => $user_id));

        $uid_card_number = $this->request->getPost('uid_card_number');
        $old_uid = (isset($verification->uid_card_number) ? $verification->uid_card_number : '');
        
        if ($uid_card_number) {
            $existing_uid = $Team_Verification_model->get_one_where(array("uid_card_number" => $uid_card_number, "user_id!=" => $user_id));
            if ($existing_uid && isset($existing_uid->id) && $existing_uid->id) {
                echo json_encode(array("success" => false, 'message' => app_lang('tv_uid_already_exists')));
                return;
            }
        }

        $data = array(
            "user_id" => $user_id,
            "uid_card_number" => $uid_card_number,
            "dbs_status" => $this->request->getPost('dbs_status'),
            "dbs_certificate_number" => $this->request->getPost('dbs_certificate_number'),
            "dbs_issue_date" => $this->request->getPost('dbs_issue_date'),
            "dbs_expiry_date" => $this->request->getPost('dbs_expiry_date'),
            "identification_type" => $this->request->getPost('identification_type'),
            "identification_number" => $this->request->getPost('identification_number'),
            "public_visibility" => $this->request->getPost('public_visibility') ? 1 : 0,
            "verification_notes" => $this->request->getPost('verification_notes'),
            "updated_at" => get_current_utc_time()
        );

        $photo_file = $this->request->getPost('photo_file');
        
        if ($photo_file) {
            $old_photo_file = (isset($verification->photo_file) ? $verification->photo_file : '');
            // Delete old file from ALL possible locations before saving new one
            if ($old_photo_file) {
                $this->_delete_file_all_locations($old_photo_file, $user_id, $verification);
            }
            
            // Check if UID exists - if not, save to pending folder
            $storage_uid = $uid_card_number ? $uid_card_number : null;
            $result = $this->_move_uploaded_file($photo_file, 'profile_image', '', $user_id, $storage_uid);
            
            if (isset($result['error'])) {
                echo json_encode(array("success" => false, 'message' => 'Photo upload failed: ' . $result['error']));
                return;
            }
            $data["photo_file"] = $result['filename'];
        }

        $id_document_file = $this->request->getPost('id_document_file');
        
        if ($id_document_file) {
            $old_document_file = (isset($verification->id_document_file) ? $verification->id_document_file : '');
            // Delete old file from ALL possible locations before saving new one
            if ($old_document_file) {
                $this->_delete_file_all_locations($old_document_file, $user_id, $verification);
            }
            
            // Check if UID exists - if not, save to pending folder
            $storage_uid = $uid_card_number ? $uid_card_number : null;
            $result = $this->_move_uploaded_file($id_document_file, 'id_document', '', $user_id, $storage_uid);
            
            if (isset($result['error'])) {
                echo json_encode(array("success" => false, 'message' => 'Document upload failed: ' . $result['error']));
                return;
            }
            $data["id_document_file"] = $result['filename'];
        }

        if (isset($verification->id) && $verification->id) {
            $save_id = $Team_Verification_model->ci_save($data, $verification->id);
        } else {
            // Generate UUID for new record
            $uuid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                mt_rand(0, 0xffff),
                mt_rand(0, 0x0fff) | 0x4000,
                mt_rand(0, 0x3fff) | 0x8000,
                mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
            );
            $data["uuid"] = $uuid;
            $data["created_at"] = get_current_utc_time();
            $save_id = $Team_Verification_model->ci_save($data);
        }

        // Handle UID changes/assignment/removal
        if ($save_id && $uid_card_number !== $old_uid) {
            $updated_verification = $Team_Verification_model->get_one($save_id);
            
            if ($uid_card_number) {
                // UID assigned or changed: promote files to new UID folder
                $this->_promote_files_to_uid(
                    $user_id, 
                    $uid_card_number,
                    $old_uid, // Pass old UID so we can move files from old UID folder
                    $updated_verification->photo_file,
                    $updated_verification->id_document_file
                );
            } else if ($old_uid) {
                // UID removed: move files back to pending folder
                $this->_demote_files_to_pending(
                    $user_id,
                    $old_uid,
                    $updated_verification->photo_file,
                    $updated_verification->id_document_file
                );
            }
        }

        if ($save_id) {
            $this->_safe_log("SUCCESS: Saved with ID " . $save_id);
            echo json_encode(array("success" => true, 'message' => app_lang('record_saved'), "id" => $save_id));
        } else {
            $this->_safe_log("ERROR: Failed to save");
            echo json_encode(array("success" => false, 'message' => app_lang('error_occurred')));
        }
        $this->_safe_log("=== SAVE COMPLETED ===\n");
        
        } catch (\Exception $e) {
            $this->_safe_log("EXCEPTION: " . $e->getMessage());
            echo json_encode(array("success" => false, "message" => "Error: " . $e->getMessage()));
        }
    }

    private function _move_uploaded_file($file_name, $subfolder, $old_file = '', $user_id = null, $uid_card_number = null) {
        // Use new UID-based storage path
        $target_directory = get_verification_storage_path($user_id, $uid_card_number, $subfolder);

        // Files are now in the plugin's pending folder, not Rise CRM's temp folder
        $pending_path = PLUGINPATH . 'Team_Verification/assets/verification/users/pending/';
        $source_file = $pending_path . $file_name;
        
        if (!file_exists($source_file)) {
            log_message('error', 'Team Verification: Source file not found: ' . $source_file);
            return array('error' => 'Source file not found at: ' . $source_file);
        }

        // Validate file type - Allow all common image formats and PDF
        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_extensions = array(
            // Image formats
            'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico', 'tiff', 'tif',
            // Document format
            'pdf'
        );
        
        if (!in_array($file_extension, $allowed_extensions)) {
            log_message('error', 'Team Verification: Invalid file type: ' . $file_extension);
            return array('error' => 'Invalid file type: ' . $file_extension . '. Allowed: ' . implode(', ', $allowed_extensions));
        }

        // Use UID as filename with subfolder type (uid-image or uid-document)
        $base_name = $uid_card_number ? $uid_card_number : 'user_' . $user_id;
        $file_type_suffix = ($subfolder == 'profile_image') ? 'image' : 'document';
        $new_file_name = $base_name . '-' . $file_type_suffix . '.' . $file_extension;
        $target_file = $target_directory . $new_file_name;

        // Ensure directory exists and is writable
        if (!is_dir($target_directory)) {
            log_message('error', 'Team Verification: Target directory does not exist: ' . $target_directory);
            return array('error' => 'Target directory does not exist: ' . $target_directory);
        }

        if (!is_writable($target_directory)) {
            log_message('error', 'Team Verification: Target directory is not writable: ' . $target_directory);
            return array('error' => 'Target directory not writable: ' . $target_directory . ' (permissions: ' . substr(sprintf('%o', fileperms($target_directory)), -4) . ')');
        }

        if (copy($source_file, $target_file)) {
            unlink($source_file);
            log_message('info', 'Team Verification: File saved successfully: ' . $target_file);
            return array('filename' => $new_file_name);
        } else {
            log_message('error', 'Team Verification: Failed to copy file from ' . $source_file . ' to ' . $target_file);
            return array('error' => 'Failed to copy file from temp to target directory. Check folder permissions.');
        }
    }
    
    /**
     * Delete file from all possible locations (pending, UID folders, legacy)
     * Used when replacing files to prevent orphaned data
     */
    private function _delete_file_all_locations($filename, $user_id, $verification) {
        if (!$filename) {
            return;
        }
        
        $deleted = false;
        $subfolders = array('profile_image', 'id_document', ''); // Check new subfolders + root for backwards compatibility
        
        // Try current UID folder with subfolders
        if (isset($verification->uid_card_number) && !empty($verification->uid_card_number)) {
            foreach ($subfolders as $subfolder) {
                $uid_path = get_verification_storage_path($user_id, $verification->uid_card_number, $subfolder);
                if (file_exists($uid_path . $filename)) {
                    unlink($uid_path . $filename);
                    log_message('info', 'Team Verification: Deleted old file from UID folder: ' . $uid_path . $filename);
                    $deleted = true;
                }
            }
        }
        
        // Try pending folder with subfolders
        foreach ($subfolders as $subfolder) {
            $pending_path = get_verification_storage_path($user_id, null, $subfolder);
            if (file_exists($pending_path . $filename)) {
                unlink($pending_path . $filename);
                log_message('info', 'Team Verification: Deleted old file from pending folder: ' . $pending_path . $filename);
                $deleted = true;
            }
        }
        
        // Search all possible base paths recursively if still not found
        if (!$deleted) {
            $base_paths = array(
                PLUGINPATH . 'Team_Verification/assets/verification/users/',
                PLUGINPATH . 'Team_Verification/assets/verified_images/'
            );
            foreach ($base_paths as $base_path) {
                if (is_dir($base_path)) {
                    $iterator = new \RecursiveIteratorIterator(
                        new \RecursiveDirectoryIterator($base_path, \RecursiveDirectoryIterator::SKIP_DOTS),
                        \RecursiveIteratorIterator::SELF_FIRST
                    );
                    foreach ($iterator as $file) {
                        if ($file->isFile() && $file->getFilename() === $filename) {
                            unlink($file->getPathname());
                            log_message('info', 'Team Verification: Deleted old file from: ' . $file->getPathname());
                            $deleted = true;
                            break 2;
                        }
                    }
                }
            }
        }
        
        // Try legacy locations
        if (!$deleted) {
            $legacy_paths = array(
                PLUGINPATH . 'Team_Verification/files/photos/' . $filename,
                PLUGINPATH . 'Team_Verification/files/documents/' . $filename
            );
            foreach ($legacy_paths as $legacy_path) {
                if (file_exists($legacy_path)) {
                    unlink($legacy_path);
                    log_message('info', 'Team Verification: Deleted old file from legacy location: ' . $legacy_path);
                    break;
                }
            }
        }
    }
    
    /**
     * Promote files from pending folder or old UID folder to new UID folder when UID is assigned/changed
     */
    private function _promote_files_to_uid($user_id, $new_uid, $old_uid = '', $photo_file = '', $id_document_file = '') {
        if (!$new_uid || !$user_id) {
            return;
        }
        
        $new_uid_path = get_verification_storage_path($user_id, $new_uid);
        
        // List of source directories to check (in priority order)
        $source_paths = array();
        
        // If UID changed, check old UID folder first
        if ($old_uid && $old_uid !== $new_uid) {
            $source_paths[] = get_verification_storage_path($user_id, $old_uid);
        }
        
        // Check pending folder
        $source_paths[] = get_verification_storage_path($user_id, null);
        
        // Move photo file from first available source
        if ($photo_file) {
            foreach ($source_paths as $source_path) {
                if (file_exists($source_path . $photo_file)) {
                    if (!file_exists($new_uid_path . $photo_file)) {
                        rename($source_path . $photo_file, $new_uid_path . $photo_file);
                    }
                    break; // Found and moved, stop searching
                }
            }
        }
        
        // Move document file from first available source
        if ($id_document_file) {
            foreach ($source_paths as $source_path) {
                if (file_exists($source_path . $id_document_file)) {
                    if (!file_exists($new_uid_path . $id_document_file)) {
                        rename($source_path . $id_document_file, $new_uid_path . $id_document_file);
                    }
                    break; // Found and moved, stop searching
                }
            }
        }
    }
    
    /**
     * Demote files from UID folder back to pending folder when UID is removed
     */
    private function _demote_files_to_pending($user_id, $old_uid, $photo_file = '', $id_document_file = '') {
        if (!$old_uid || !$user_id) {
            return;
        }
        
        $old_uid_path = get_verification_storage_path($user_id, $old_uid);
        $pending_path = get_verification_storage_path($user_id, null);
        
        // Move photo file back to pending
        if ($photo_file && file_exists($old_uid_path . $photo_file)) {
            if (!file_exists($pending_path . $photo_file)) {
                rename($old_uid_path . $photo_file, $pending_path . $photo_file);
            }
        }
        
        // Move document file back to pending
        if ($id_document_file && file_exists($old_uid_path . $id_document_file)) {
            if (!file_exists($pending_path . $id_document_file)) {
                rename($old_uid_path . $id_document_file, $pending_path . $id_document_file);
            }
        }
    }

    public function delete_file() {
        $this->_safe_log("=== DELETE FILE CALLED ===");
        
        $user_id = $this->request->getPost('user_id');
        $file_type = $this->request->getPost('file_type');
        
        $this->_safe_log("User ID: " . $user_id . ", File Type: " . $file_type);
        
        if (!$user_id || !$file_type) {
            $this->_safe_log("ERROR: Invalid request - missing parameters");
            echo json_encode(array("success" => false, 'message' => 'Invalid request'));
            return;
        }

        $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
        $verification = $Team_Verification_model->get_one_where(array("user_id" => $user_id));

        if (!$verification->id) {
            $this->_safe_log("ERROR: Verification record not found for user_id: " . $user_id);
            echo json_encode(array("success" => false, 'message' => 'Verification record not found'));
            return;
        }

        $file_field = $file_type === 'photo' ? 'photo_file' : 'id_document_file';
        $filename = $verification->$file_field;
        
        if ($filename) {
            $deleted = false;
            
            // Try current UID-based storage first
            if ($verification->uid_card_number) {
                $uid_path = get_verification_storage_path($user_id, $verification->uid_card_number);
                if (file_exists($uid_path . $filename)) {
                    unlink($uid_path . $filename);
                    $deleted = true;
                }
            }
            
            // Try pending folder
            if (!$deleted) {
                $pending_path = get_verification_storage_path($user_id, null);
                if (file_exists($pending_path . $filename)) {
                    unlink($pending_path . $filename);
                    $deleted = true;
                }
            }
            
            // Search all UID folders under verified_images if still not found (handles old UID changes)
            if (!$deleted) {
                $base_path = PLUGINPATH . 'Team_Verification/assets/verified_images/';
                if (is_dir($base_path)) {
                    $folders = glob($base_path . '*/');
                    foreach ($folders as $folder) {
                        if (file_exists($folder . $filename)) {
                            unlink($folder . $filename);
                            $deleted = true;
                            break;
                        }
                    }
                }
            }
            
            // Fallback to legacy location
            if (!$deleted) {
                $subfolder = $file_type === 'photo' ? 'photos' : 'documents';
                $legacy_path = PLUGINPATH . "Team_Verification/files/" . $subfolder . "/" . $filename;
                if (file_exists($legacy_path)) {
                    unlink($legacy_path);
                }
            }
        }

        $data = array($file_field => NULL);
        $Team_Verification_model->ci_save($data, $verification->id);

        $this->_safe_log("SUCCESS: File deleted and record updated");
        $this->_safe_log("=== DELETE FILE COMPLETED ===\n");
        
        echo json_encode(array("success" => true, 'message' => app_lang('file_deleted')));
    }

    public function generate_uid() {
        $this->_safe_log("=== GENERATE UID CALLED ===");
        
        $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
        $max_attempts = 10;
        $attempt = 0;
        
        // Format: UID-YYYY-XXXXX (e.g., UID-2025-A3B4C)
        $year = date('Y');
        
        while ($attempt < $max_attempts) {
            $random_part = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 5));
            $uid = "UID-{$year}-{$random_part}";
            
            $this->_safe_log("Attempt " . ($attempt + 1) . ": Generated UID: " . $uid);
            
            // Check if UID already exists
            $existing = $Team_Verification_model->get_one_where(array("uid_card_number" => $uid));
            
            if (!$existing || !isset($existing->id) || !$existing->id) {
                $this->_safe_log("SUCCESS: UID is unique: " . $uid);
                echo json_encode(array(
                    "success" => true, 
                    "uid" => $uid,
                    "message" => app_lang('tv_uid_generated_success')
                ));
                return;
            }
            
            $attempt++;
        }
        
        echo json_encode(array(
            "success" => false, 
            "message" => app_lang('error_occurred')
        ));
    }

    public function view_id_card($user_id = 0) {
        if (!$user_id) {
            show_404();
        }

        $user_info = $this->Users_model->get_one($user_id);
        if (!$user_info->id) {
            show_404();
        }

        $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
        $verification = $Team_Verification_model->get_one_where(array("user_id" => $user_id));

        if (!$verification->id) {
            show_404();
        }

        $view_data['user_info'] = $user_info;
        $view_data['verification'] = $verification;
        
        return $this->template->view('Team_Verification\Views\admin\view_id_card', $view_data);
    }

    public function embed_code() {
        $embed_code = '<!-- AuditLog Embed Code with Inline Styles for Rise CRM -->
<!-- Paste this entire code into your custom page editor -->

<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', sans-serif; max-width: 900px; margin: 0 auto; padding: 20px;">
    
    <!-- Header -->
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 40px 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); margin-bottom: 30px; text-align: center;">
        <h1 style="margin: 0 0 10px 0; font-size: 2.5rem; font-weight: 700; color: white;">AuditLog - Team Verification Package</h1>
        <div style="font-size: 1.2rem; opacity: 0.95; font-weight: 500;">Version 2.1.0 - Ready for Download</div>
    </div>

    <!-- Download Box -->
    <div style="background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); border: 3px solid #2196f3; padding: 30px; border-radius: 12px; margin: 30px 0; text-align: center; box-shadow: 0 4px 10px rgba(33, 150, 243, 0.2);">
        <h2 style="color: #1565c0; margin: 0 0 15px 0; font-size: 1.8rem;">Download Package</h2>
        <div style="font-size: 1.1rem; color: #424242; margin: 10px 0;">
            <strong>AuditLog_Public_Team_Standalone_v2.1.0.zip</strong> (1.2 MB)
        </div>
        <p style="margin: 10px 0;">Complete solution with standalone public page + Rise CRM plugin</p>
        <a href="https://management.omniex.uk/plugins_update/AuditLog-VerifyiD/AuditLog_Public_Team_Standalone_v2.1.0.zip" style="display: inline-block; background: #2196f3; color: white !important; padding: 18px 40px; border-radius: 8px; text-decoration: none; font-weight: 700; font-size: 1.2rem; margin-top: 20px; box-shadow: 0 4px 10px rgba(33, 150, 243, 0.3);">Download Now</a>
    </div>

    <!-- Package Contents -->
    <div style="background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin: 25px 0; border-left: 4px solid #2196f3;">
        <h2 style="color: #1565c0; margin: 0 0 20px 0; font-size: 1.5rem;">Package Contents</h2>
        <div style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span><strong>public_team.php</strong> - Standalone public directory page</div>
        <div style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span><strong>Team_Verification/</strong> - Rise CRM plugin for admin features</div>
        <div style="padding: 12px 0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span><strong>INSTALLATION_INSTRUCTIONS.txt</strong> - Complete setup guide</div>
    </div>

    <!-- Quick Installation -->
    <div style="background: #f5f5f5; padding: 25px; border-radius: 10px; margin: 25px 0;">
        <h2 style="color: #1565c0; margin: 0 0 20px 0; font-size: 1.5rem;">Quick Installation</h2>
        <ol style="margin: 0; padding-left: 25px;">
            <li style="padding: 10px 0; font-size: 1rem; line-height: 1.6;">Extract the zip file</li>
            <li style="padding: 10px 0; font-size: 1rem; line-height: 1.6;">Upload <span style="background: #263238; color: #aed581; padding: 3px 8px; border-radius: 4px; font-family: \'Courier New\', monospace; font-size: 0.9rem;">public_team.php</span> to your Rise CRM web root</li>
            <li style="padding: 10px 0; font-size: 1rem; line-height: 1.6;">Edit database credentials in <span style="background: #263238; color: #aed581; padding: 3px 8px; border-radius: 4px; font-family: \'Courier New\', monospace; font-size: 0.9rem;">public_team.php</span> (lines 9-13)</li>
            <li style="padding: 10px 0; font-size: 1rem; line-height: 1.6;">Install Team_Verification plugin via Rise CRM Settings → Plugins</li>
            <li style="padding: 10px 0; font-size: 1rem; line-height: 1.6;">Visit: <span style="background: #263238; color: #aed581; padding: 3px 8px; border-radius: 4px; font-family: \'Courier New\', monospace; font-size: 0.9rem;">https://yourdomain.com/public_team.php</span></li>
        </ol>
    </div>

    <!-- Features -->
    <div style="background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin: 25px 0; border-left: 4px solid #2196f3;">
        <h2 style="color: #1565c0; margin: 0 0 20px 0; font-size: 1.5rem;">Features</h2>
        <div style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span>Public team directory with search functionality</div>
        <div style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span>Individual member profiles with UUID URLs</div>
        <div style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span>DBS verification status display</div>
        <div style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span>QR code generation for profile sharing</div>
        <div style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span>Admin team verification management</div>
        <div style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span>ID card view and download (Badgy 100 compatible)</div>
        <div style="padding: 12px 0; border-bottom: 1px solid #e0e0e0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span>UID card number generation</div>
        <div style="padding: 12px 0; font-size: 1rem; color: #424242;"><span style="color: #4caf50; font-weight: bold; margin-right: 10px;">&#10003;</span>10-year data retention for inactive accounts</div>
    </div>

    <!-- Public URLs -->
    <div style="background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%); border: 2px solid #ff9800; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <h2 style="color: #e65100; margin: 0 0 15px 0; font-size: 1.4rem;">Public URLs</h2>
        <p style="margin: 10px 0; font-size: 1rem;"><strong style="color: #e65100;">Directory:</strong> <span style="background: #263238; color: #aed581; padding: 3px 8px; border-radius: 4px; font-family: \'Courier New\', monospace; font-size: 0.9rem;">/public_team.php</span></p>
        <p style="margin: 10px 0; font-size: 1rem;"><strong style="color: #e65100;">Profile:</strong> <span style="background: #263238; color: #aed581; padding: 3px 8px; border-radius: 4px; font-family: \'Courier New\', monospace; font-size: 0.9rem;">/public_team.php?action=profile&uuid=XXX</span></p>
    </div>

</div>';

        $view_data['embed_code'] = $embed_code;
        return $this->template->rander("Team_Verification\Views\admin\embed_code", $view_data);
    }

    public function get_public_json() {
        // API endpoint to return team member data as JSON
        $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
        
        $options = array(
            "public_visibility" => 1
        );
        
        $members = $Team_Verification_model->get_public_team_members($options);
        
        $result = array();
        foreach ($members as $member) {
            // Determine if authorized
            $is_authorized = ($member->user_status === 'active' && $member->dbs_status === 'verified');
            
            // Get photo URL
            if ($member->photo_file) {
                $photo_url = get_uri('files/team_verification/' . $member->photo_file);
            } else if ($member->user_image) {
                $photo_url = get_uri('files/profile_images/' . $member->user_image);
            } else {
                $photo_url = '';
            }
            
            // Generate QR code URL
            $profile_external_url = base_url('public_team.php?action=profile&uuid=' . $member->uuid);
            $qr_code_url = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode($profile_external_url);
            
            $result[] = array(
                'id' => $member->user_id,
                'first_name' => $member->first_name,
                'last_name' => $member->last_name,
                'job_title' => $member->job_title ? $member->job_title : '',
                'dbs_status' => $member->dbs_status,
                'is_authorized' => $is_authorized,
                'photo_url' => $photo_url,
                'uid_card_number' => $member->uid_card_number ? $member->uid_card_number : '',
                'uuid' => $member->uuid,
                'qr_code_url' => $qr_code_url,
                'profile_external_url' => $profile_external_url,
                'dbs_certificate_number' => $member->dbs_certificate_number ? $member->dbs_certificate_number : '',
                'dbs_issue_date' => $member->dbs_issue_date ? $member->dbs_issue_date : '',
                'dbs_expiry_date' => $member->dbs_expiry_date ? $member->dbs_expiry_date : ''
            );
        }
        
        header('Content-Type: application/json');
        echo json_encode($result);
        exit();
    }

    public function public_directory_embed() {
        $api_url = get_uri('team_verification/get_public_json');
        $base_url = base_url();
        
        $embed_code = '<!-- Public Team Directory Embed Code for Rise CRM (No iframe - Modal popup version) -->
<!-- Paste this code into your Rise CRM custom page editor -->
<!-- This version shows profiles in a popup modal - NO 404 errors! -->

<div id="team-verification-directory" style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', sans-serif; max-width: 100%; margin: 0 auto; padding: 20px;">
    
    <!-- Header -->
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); margin-bottom: 20px; text-align: center;">
        <h1 style="margin: 0 0 10px 0; font-size: 2rem; font-weight: 700; color: white;">Team Verification Directory</h1>
        <p style="margin: 0; font-size: 1rem; opacity: 0.95;">View authorized team members and their verification status</p>
    </div>

    <!-- Search Box -->
    <div style="margin-bottom: 30px;">
        <input type="text" id="team-search" placeholder="Search by name or job title..." style="width: 100%; max-width: 500px; padding: 12px 16px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 1rem; box-sizing: border-box; display: block; margin: 0 auto;">
    </div>

    <!-- Loading Indicator -->
    <div id="loading-indicator" style="text-align: center; padding: 60px; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <p style="color: #7f8c8d; font-size: 1.1rem; margin: 0;">Loading team directory...</p>
    </div>

    <!-- Team Members Grid -->
    <div id="team-members-grid" style="display: none; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin-bottom: 30px;"></div>

    <!-- No Results Message -->
    <div id="no-results" style="display: none; text-align: center; padding: 60px; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
        <p style="color: #7f8c8d; font-size: 1.1rem; margin: 0;">No team members found</p>
    </div>

    <!-- Profile Modal -->
    <div id="profile-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 9999; overflow-y: auto; padding: 20px;">
        <div style="max-width: 900px; margin: 40px auto; background: white; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); position: relative;">
            <button id="close-modal" style="position: absolute; top: 15px; right: 15px; background: #e74c3c; color: white; border: none; border-radius: 50%; width: 40px; height: 40px; font-size: 24px; cursor: pointer; z-index: 10; line-height: 1;">&#215;</button>
            <div id="profile-content" style="padding: 40px;"></div>
        </div>
    </div>

</div>

<script>
(function() {
    var apiUrl = "' . $api_url . '";
    var baseUrl = "' . $base_url . '";
    var allMembers = [];

    function closeModal() {
        document.getElementById("profile-modal").style.display = "none";
        document.body.style.overflow = "auto";
    }

    function showProfile(member) {
        var modal = document.getElementById("profile-modal");
        var content = document.getElementById("profile-content");
        
        var authBanner = member.is_authorized
            ? "<div style=\"background: linear-gradient(135deg, #28a745 0%, #20c997 100%); color: white; padding: 30px; border-radius: 8px; text-align: center; margin-bottom: 30px;\"><h2 style=\"margin: 0 0 10px 0; font-size: 2rem;\">&#10003; AUTHORIZED</h2><p style=\"margin: 0; font-size: 1.1rem;\">DBS Verified Team Member</p></div>"
            : "<div style=\"background: #dc3545; color: white; padding: 30px; border-radius: 8px; text-align: center; margin-bottom: 30px;\"><h2 style=\"margin: 0 0 10px 0; font-size: 2rem;\">&#10005; NOT AUTHORIZED</h2><p style=\"margin: 0; font-size: 1.1rem;\">This team member is not currently authorized</p></div>";
        
        var photoHtml = member.photo_url 
            ? "<img src=\"" + member.photo_url + "\" style=\"width: 250px; height: 250px; border-radius: 50%; object-fit: cover; display: block; margin: 0 auto 20px; border: 5px solid #f0f0f0;\" alt=\"" + member.first_name + " " + member.last_name + "\">"
            : "<div style=\"width: 250px; height: 250px; border-radius: 50%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; font-size: 5rem; color: white; font-weight: bold; margin: 0 auto 20px;\">" + member.first_name.charAt(0) + member.last_name.charAt(0) + "</div>";
        
        var dbsDetails = "";
        if (member.dbs_status === "verified" && member.dbs_certificate_number) {
            dbsDetails = "<div style=\"background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;\"><h3 style=\"color: #2c3e50; margin: 0 0 15px 0;\">DBS Verification Details</h3><div style=\"display: grid; grid-template-columns: 1fr 1fr; gap: 15px;\"><div><strong>Certificate Number:</strong><br>" + member.dbs_certificate_number + "</div>" + (member.dbs_issue_date ? "<div><strong>Issue Date:</strong><br>" + member.dbs_issue_date + "</div>" : "") + (member.dbs_expiry_date ? "<div><strong>Expiry Date:</strong><br>" + member.dbs_expiry_date + "</div>" : "") + "</div></div>";
        }
        
        var qrSection = "<div style=\"text-align: center; margin: 30px 0; padding: 20px; background: #f8f9fa; border-radius: 8px;\"><h3 style=\"color: #2c3e50; margin: 0 0 15px 0;\">Share Profile</h3><img src=\"" + member.qr_code_url + "\" style=\"width: 200px; height: 200px; margin: 10px auto; display: block;\" alt=\"QR Code\"><p style=\"margin: 10px 0 0 0; color: #7f8c8d; font-size: 0.9rem;\">Scan to view this profile</p></div>";
        
        content.innerHTML = authBanner + 
            "<div style=\"text-align: center;\">" + photoHtml + 
            "<h2 style=\"margin: 0 0 10px 0; font-size: 2rem; color: #2c3e50;\">" + member.first_name + " " + member.last_name + "</h2>" +
            "<p style=\"margin: 0 0 20px 0; color: #7f8c8d; font-size: 1.2rem;\">" + (member.job_title || "Team Member") + "</p>" +
            (member.uid_card_number ? "<p style=\"margin: 0 0 20px 0; color: #7f8c8d;\"><strong>UID Card Number:</strong> " + member.uid_card_number + "</p>" : "") +
            "</div>" +
            dbsDetails +
            qrSection;
        
        modal.style.display = "block";
        document.body.style.overflow = "hidden";
    }

    function loadTeamMembers() {
        fetch(apiUrl)
            .then(function(response) { return response.json(); })
            .then(function(members) {
                allMembers = members;
                document.getElementById("loading-indicator").style.display = "none";
                displayMembers(members);
            })
            .catch(function(error) {
                document.getElementById("loading-indicator").innerHTML = "<p style=\"color: #e74c3c; font-size: 1.1rem; margin: 0;\">Error loading team directory. Please refresh the page.</p>";
            });
    }

    function displayMembers(members) {
        var grid = document.getElementById("team-members-grid");
        var noResults = document.getElementById("no-results");
        
        if (members.length === 0) {
            grid.style.display = "none";
            noResults.style.display = "block";
            return;
        }

        grid.style.display = "grid";
        noResults.style.display = "none";
        grid.innerHTML = "";

        members.forEach(function(member) {
            var card = document.createElement("div");
            card.style.cssText = "background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden; transition: transform 0.2s; cursor: pointer;";
            card.onmouseover = function() { this.style.transform = "translateY(-4px)"; this.style.boxShadow = "0 4px 12px rgba(0,0,0,0.15)"; };
            card.onmouseout = function() { this.style.transform = "translateY(0)"; this.style.boxShadow = "0 2px 8px rgba(0,0,0,0.1)"; };
            card.onclick = function() { showProfile(member); };

            var photoHtml = member.photo_url 
                ? "<img src=\"" + member.photo_url + "\" style=\"width: 100%; height: 280px; object-fit: cover; display: block;\" alt=\"" + member.first_name + " " + member.last_name + "\">"
                : "<div style=\"width: 100%; height: 280px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; font-size: 4rem; color: white; font-weight: bold;\">" + member.first_name.charAt(0) + member.last_name.charAt(0) + "</div>";

            var statusBadge = "";
            if (member.dbs_status === "verified") {
                statusBadge = "<span style=\"display: inline-block; padding: 6px 12px; border-radius: 20px; font-size: 0.85rem; font-weight: 500; background: #d4edda; color: #155724; margin-right: 5px;\">&#10003; DBS Verified</span>";
            } else if (member.dbs_status === "pending") {
                statusBadge = "<span style=\"display: inline-block; padding: 6px 12px; border-radius: 20px; font-size: 0.85rem; font-weight: 500; background: #fff3cd; color: #856404; margin-right: 5px;\">Pending</span>";
            } else if (member.dbs_status === "expired") {
                statusBadge = "<span style=\"display: inline-block; padding: 6px 12px; border-radius: 20px; font-size: 0.85rem; font-weight: 500; background: #f8d7da; color: #721c24; margin-right: 5px;\">Expired</span>";
            }

            var authBadge = member.is_authorized 
                ? "<span style=\"display: inline-block; padding: 6px 12px; border-radius: 20px; font-size: 0.85rem; font-weight: 500; background: #28a745; color: white;\">&#10003; AUTHORIZED</span>"
                : "<span style=\"display: inline-block; padding: 6px 12px; border-radius: 20px; font-size: 0.85rem; font-weight: 500; background: #dc3545; color: white;\">NOT AUTHORIZED</span>";

            card.innerHTML = photoHtml + 
                "<div style=\"padding: 20px;\">" +
                "<h3 style=\"margin: 0 0 8px 0; font-size: 1.25rem; font-weight: 600; color: #2c3e50;\">" + member.first_name + " " + member.last_name + "</h3>" +
                "<p style=\"margin: 0 0 12px 0; color: #7f8c8d; font-size: 0.9rem;\">" + (member.job_title || "Team Member") + "</p>" +
                "<div style=\"margin-bottom: 12px;\">" + statusBadge + "</div>" +
                "<div style=\"margin-bottom: 12px;\">" + authBadge + "</div>" +
                "<div style=\"text-align: center; padding-top: 12px; border-top: 1px solid #ecf0f1;\">" +
                "<span style=\"color: #3498db; font-weight: 500; font-size: 0.9rem;\">Click to view full profile &#8594;</span>" +
                "</div>" +
                "</div>";

            grid.appendChild(card);
        });
    }

    function filterMembers() {
        var searchTerm = document.getElementById("team-search").value.toLowerCase();
        var filtered = allMembers.filter(function(member) {
            var fullName = (member.first_name + " " + member.last_name).toLowerCase();
            var jobTitle = (member.job_title || "").toLowerCase();
            return fullName.indexOf(searchTerm) !== -1 || jobTitle.indexOf(searchTerm) !== -1;
        });
        displayMembers(filtered);
    }
    
    document.getElementById("close-modal").addEventListener("click", closeModal);
    document.getElementById("profile-modal").addEventListener("click", function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    document.addEventListener("keydown", function(e) {
        if (e.key === "Escape") {
            closeModal();
        }
    });
    
    document.getElementById("team-search").addEventListener("input", filterMembers);
    
    loadTeamMembers();
})();
</script>';

        $view_data['embed_code'] = $embed_code;
        $view_data['embed_type'] = 'public_directory';
        return $this->template->rander("Team_Verification\Views\admin\embed_code", $view_data);
    }
}
