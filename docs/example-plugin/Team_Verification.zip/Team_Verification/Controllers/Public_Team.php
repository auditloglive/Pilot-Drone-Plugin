<?php

namespace Team_Verification\Controllers;

use App\Controllers\App_Controller;

class Public_Team extends App_Controller {

    public $Users_model;

    public function __construct() {
        parent::__construct();
        $this->Users_model = model('App\Models\Users_model');
    }

    public function index() {
        $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
        
        $options = array(
            "public_visibility" => 1,
            "status" => "active"
        );
        
        $view_data['team_members'] = $Team_Verification_model->get_public_team_members($options);
        
        return view('Team_Verification\Views\public\directory_simple', $view_data);
    }

    public function profile($uuid = '') {
        if (!$uuid) {
            show_404();
        }

        $Team_Verification_model = new \Team_Verification\Models\Team_Verification_model();
        $verification = $Team_Verification_model->get_one_where(array("uuid" => $uuid, "public_visibility" => 1));

        if (!$verification->id) {
            show_404();
        }

        $user_info = $this->Users_model->get_one($verification->user_id);
        
        if (!$user_info->id || $user_info->deleted || $user_info->user_type !== "staff") {
            show_404();
        }

        $is_authorized = ($user_info->status === "active" && $verification->dbs_status === 'verified');

        $view_data['user_info'] = $user_info;
        $view_data['verification'] = $verification;
        $view_data['is_authorized'] = $is_authorized;
        
        return view('Team_Verification\Views\public\profile_simple', $view_data);
    }

    public function submit_report() {
        $user_id = $this->request->getPost('user_id');
        $reporter_name = $this->request->getPost('reporter_name');
        $reporter_email = $this->request->getPost('reporter_email');
        $reporter_phone = $this->request->getPost('reporter_phone');
        $reason = $this->request->getPost('reason');

        if (!$user_id || !$reporter_name || !$reporter_email || !$reason) {
            echo json_encode(array("success" => false, "message" => app_lang('tv_report_missing_fields')));
            return;
        }

        $user_info = $this->Users_model->get_one($user_id);
        if (!$user_info->id) {
            echo json_encode(array("success" => false, "message" => app_lang('tv_report_invalid_user')));
            return;
        }

        $ticket_data = array(
            'title' => 'Unauthorized Team Member Report: ' . $user_info->first_name . ' ' . $user_info->last_name,
            'description' => "An unauthorized team member has been reported.\n\n" .
                           "**Team Member Details:**\n" .
                           "Name: " . $user_info->first_name . ' ' . $user_info->last_name . "\n" .
                           "Email: " . $user_info->email . "\n" .
                           "Job Title: " . ($user_info->job_title ?: 'N/A') . "\n" .
                           "User ID: " . $user_id . "\n\n" .
                           "**Reporter Details:**\n" .
                           "Name: " . $reporter_name . "\n" .
                           "Email: " . $reporter_email . "\n" .
                           "Phone: " . ($reporter_phone ?: 'N/A') . "\n\n" .
                           "**Reason for Report:**\n" . $reason . "\n\n" .
                           "**Profile URL:** " . base_url('public_team/profile/' . $user_id),
            'ticket_type_id' => 0,
            'client_id' => 0,
            'creator_name' => $reporter_name,
            'creator_email' => $reporter_email,
            'created_at' => get_current_utc_time(),
            'labels' => 'unauthorized-report'
        );

        $Tickets_model = model('App\Models\Tickets_model');
        $ticket_id = $Tickets_model->ci_save($ticket_data);

        if ($ticket_id) {
            echo json_encode(array(
                "success" => true, 
                "message" => app_lang('tv_report_submitted_success'),
                "ticket_id" => $ticket_id
            ));
        } else {
            echo json_encode(array("success" => false, "message" => app_lang('tv_report_submission_failed')));
        }
    }
}
